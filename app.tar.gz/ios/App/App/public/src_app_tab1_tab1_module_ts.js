"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_tab1_module_ts"],{

/***/ 450:
/*!**********************************************************!*\
  !*** ./src/app/authentication/authentication.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationService": () => (/* binding */ AuthenticationService)
/* harmony export */ });
/* harmony import */ var _Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _ionic_enterprise_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-enterprise/auth */ 6824);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 4505);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ 4766);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _vault_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../vault.service */ 3972);








class AuthenticationService extends _ionic_enterprise_auth__WEBPACK_IMPORTED_MODULE_1__.IonicAuth {
  constructor(platform, ngZone, vaultService) {
    super(platform.is('hybrid') ? { ..._environments_environment__WEBPACK_IMPORTED_MODULE_2__.nativeIonicAuthOptions,
      tokenStorageProvider: vaultService.vault
    } : _environments_environment__WEBPACK_IMPORTED_MODULE_2__.webIonicAuthOptions);
    this.ngZone = ngZone;
    this.vaultService = vaultService;
    this.authenticationChange = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject(false);
    this.authenticationChange$ = this.authenticationChange.asObservable();
    this.isAuthenticated().then(authenticated => {
      this.onAuthChange(authenticated);
    });
  }

  onLoginSuccess() {
    var _this = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.onAuthChange(true);
    })();
  }

  onLogout() {
    var _this2 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.onAuthChange(false);
    })();
  }

  onAuthChange(isAuthenticated) {
    var _this3 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.ngZone.run(() => {
        _this3.authenticationChange.next(isAuthenticated);
      });
    })();
  }

}

AuthenticationService.ɵfac = function AuthenticationService_Factory(t) {
  return new (t || AuthenticationService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_vault_service__WEBPACK_IMPORTED_MODULE_3__.VaultService));
};

AuthenticationService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
  token: AuthenticationService,
  factory: AuthenticationService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 4588:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 1028);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page,
    }
];
class Tab1PageRoutingModule {
}
Tab1PageRoutingModule.ɵfac = function Tab1PageRoutingModule_Factory(t) { return new (t || Tab1PageRoutingModule)(); };
Tab1PageRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: Tab1PageRoutingModule });
Tab1PageRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](Tab1PageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule] }); })();


/***/ }),

/***/ 9634:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 1028);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 4081);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1-routing.module */ 4588);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);







class Tab1PageModule {
}
Tab1PageModule.ɵfac = function Tab1PageModule_Factory(t) { return new (t || Tab1PageModule)(); };
Tab1PageModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: Tab1PageModule });
Tab1PageModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
        _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
        _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab1PageRoutingModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](Tab1PageModule, { declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page], imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
        _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
        _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab1PageRoutingModule] }); })();


/***/ }),

/***/ 1028:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var _Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _authentication_authentication_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../authentication/authentication.service */ 450);
/* harmony import */ var _vault_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../vault.service */ 3972);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);






class Tab1Page {
  constructor(authenticationService, vaultService, platform) {
    var _this = this;

    this.authenticationService = authenticationService;
    this.vaultService = vaultService;
    this.platform = platform;
    this.authenticationChange$ = authenticationService.authenticationChange$;
    this.platform.resume.subscribe( /*#__PURE__*/(0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.update();
    }));
  }

  ionViewDidEnter() {
    var _this2 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.update();
    })();
  }

  update() {
    var _this3 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.isEmpty = (yield _this3.vaultService.isEmpty()) ? 'Vault is empty' : 'Vault has data';
      _this3.isLocked = (yield _this3.vaultService.isLocked()) ? 'Vault is locked' : 'Vault is unlocked';
    })();
  }

  login() {
    var _this4 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // This line is required if iosWebView is shared and we are using Identity Vault. It prevents the privacy screen from displaying
      // Device.setHideScreenOnBackground(false);
      yield _this4.authenticationService.login();
    })();
  }

  logout() {
    var _this5 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        _this5.authenticationService.logout();
      } catch (err) {
        console.error(err);
      }
    })();
  }

  refresh() {
    var _this6 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(yield _this6.authenticationService.isRefreshTokenAvailable());
      const token = yield _this6.authenticationService.getAccessToken();
      console.log(token);
      yield _this6.authenticationService.refreshSession();
      const atoken = yield _this6.authenticationService.getAccessToken();
      console.log(atoken);

      if (atoken !== token) {
        alert('Token was refreshed');
      }
    })();
  }

  lock() {
    var _this7 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (yield _this7.vaultService.lock()) {
        const isLocked = yield _this7.vaultService.isLocked();

        if (!isLocked) {
          _this7.vaultService.presentAlert('Error', 'Vault lock call was successfully made but is returning locked is false');
        }
      }

      yield _this7.update();
    })();
  }

  unlock() {
    var _this8 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this8.vaultService.unlock();
      yield _this8.update();
    })();
  }

  checkIsEmpty() {
    var _this9 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const isEmpty = yield _this9.vaultService.isEmpty();

      _this9.vaultService.presentAlert('Message', `isEmpty is ${isEmpty}"`);
    })();
  }

  clear() {
    var _this10 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this10.vaultService.clear();
      yield _this10.update();
    })();
  }

  setData() {
    var _this11 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this11.vaultService.setData();
      yield _this11.update();
    })();
  }

  getData() {
    var _this12 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const data = yield _this12.vaultService.getData();

        _this12.vaultService.presentAlert('Message', `The vault data read as "${data}"`);
      } catch (err) {
        _this12.vaultService.presentAlert('Error', `Failed to get data "${err.message}" (Error Code: ${err.code})`);

        yield _this12.update();
      }
    })();
  }

  checkBio() {
    var _this13 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const hasBio = yield _this13.vaultService.hasBiometrics();
      alert('Biometrics is ' + hasBio);
    })();
  }

  useSecure(enabled) {
    var _this14 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this14.vaultService.useSecure(enabled);
    })();
  }

  setToPasscode() {
    var _this15 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this15.vaultService.switchPasscode();
    })();
  }

  setToBoth() {
    var _this16 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this16.vaultService.switchBoth();
    })();
  }

}

Tab1Page.ɵfac = function Tab1Page_Factory(t) {
  return new (t || Tab1Page)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_authentication_authentication_service__WEBPACK_IMPORTED_MODULE_1__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_vault_service__WEBPACK_IMPORTED_MODULE_2__.VaultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.Platform));
};

Tab1Page.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: Tab1Page,
  selectors: [["app-tab1"]],
  decls: 48,
  vars: 13,
  consts: [[3, "translucent"], [3, "hidden", "click"], [3, "fullscreen"], ["collapse", "condense"], ["size", "large"], [2, "padding", "25px"], [3, "click"]],
  template: function Tab1Page_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons")(3, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_6_listener() {
        return ctx.login();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, "Sign In");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_9_listener() {
        return ctx.logout();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11, "Sign Out");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "ion-content", 2)(13, "ion-header", 3)(14, "ion-toolbar")(15, "ion-title", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16, "Test");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "div", 5)(18, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_18_listener() {
        return ctx.lock();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Lock");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_20_listener() {
        return ctx.unlock();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21, "Unlock");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_22_listener() {
        return ctx.clear();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](23, "Clear");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](24, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_24_listener() {
        return ctx.refresh();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Refresh");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_26_listener() {
        return ctx.checkBio();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, "Check Bio");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_28_listener() {
        return ctx.getData();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](29, "Get Data");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_30_listener() {
        return ctx.setData();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](31, "Set Data");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_32_listener() {
        return ctx.useSecure(true);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, "Switch to Secure");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_34_listener() {
        return ctx.useSecure(false);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](35, "Switch to Bio");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_36_listener() {
        return ctx.setToBoth();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](37, "Switch to Both");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_38_listener() {
        return ctx.setToPasscode();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](39, "Switch to Passcode");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](40, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function Tab1Page_Template_ion_button_click_40_listener() {
        return ctx.checkIsEmpty();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](41, "Check isEmpty");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "div", 5)(43, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](44);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](45, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("translucent", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" Authenticated=", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 7, ctx.authenticationChange$), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("hidden", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 9, ctx.authenticationChange$));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("hidden", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](10, 11, ctx.authenticationChange$) === false);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](32);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.isEmpty);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.isLocked);
    }
  },
  dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _angular_common__WEBPACK_IMPORTED_MODULE_5__.AsyncPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIxLnBhZ2Uuc2NzcyJ9 */"]
});

/***/ }),

/***/ 3972:
/*!**********************************!*\
  !*** ./src/app/vault.service.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VaultService": () => (/* binding */ VaultService)
/* harmony export */ });
/* harmony import */ var _Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-enterprise/identity-vault */ 7312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);





class VaultService {
  constructor(platform, alertController) {
    this.platform = platform;
    this.alertController = alertController;
    this.config = {
      key: 'io.ionic.iv-test-bio5',
      type: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.DeviceSecurity,
      deviceSecurityType: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.Biometrics,
      lockAfterBackgrounded: 2000,
      shouldClearVaultAfterTooManyFailedAttempts: true,
      customPasscodeInvalidUnlockAttempts: 10,
      unlockVaultOnLoad: false
    };
    this.init();
  }

  init() {
    var _this = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.platform.ready();
      _this.vault = _capacitor_core__WEBPACK_IMPORTED_MODULE_1__.Capacitor.getPlatform() === 'web' ? new _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.BrowserVault(_this.config) : new _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.Vault(_this.config);

      _this.vault.onConfigChanged(() => {
        console.log('Vault configuration was changed', _this.config);
      });

      _this.vault.onLock(() => {
        console.log('Vault was locked');
      });

      _this.vault.onUnlock(() => {
        console.log('Vault was unlocked');
      });

      _this.vault.onError(err => {
        console.error('Vault error', err);

        _this.presentAlert('Vault Error', err.code + ': ' + err.message);
      });

      yield _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.Device.setHideScreenOnBackground(true);
    })();
  }

  presentAlert(header, message) {
    var _this2 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertController.create({
        header,
        message,
        buttons: ['OK']
      });
      yield alert.present();
      const {
        role
      } = yield alert.onDidDismiss();
      return role;
    })();
  }

  switchBoth() {
    var _this3 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3.config.type = _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.DeviceSecurity;
      _this3.config.deviceSecurityType = _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.Both;
      yield _this3.vault.updateConfig(_this3.config);

      _this3.setData();
    })();
  }

  switchPasscode() {
    var _this4 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        _this4.vault = new _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.Vault({
          key: 'io.ionic.iv-test-sysp',
          type: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.SecureStorage,
          deviceSecurityType: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.None,
          lockAfterBackgrounded: 2000,
          shouldClearVaultAfterTooManyFailedAttempts: true,
          customPasscodeInvalidUnlockAttempts: 10,
          unlockVaultOnLoad: false
        });
        yield _this4.vault.setValue('blar', 'stuff'); // This code blows up on an iOS device without fingerprint/bio and only system passcode

        yield _this4.vault.updateConfig({
          key: 'io.ionic.iv-test-sysp',
          type: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.DeviceSecurity,
          deviceSecurityType: _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.SystemPasscode,
          lockAfterBackgrounded: 2000,
          shouldClearVaultAfterTooManyFailedAttempts: true,
          customPasscodeInvalidUnlockAttempts: 10,
          unlockVaultOnLoad: false
        });
      } catch (err) {
        alert(`${err.message} (Error Code: ${err.code})`);
      }
    })();
  }

  lock() {
    var _this5 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this5.vault.lock();
        console.log('vault was locked');
        return true;
      } catch (err) {
        console.error('vault.service.ts lock()', err);
        return false;
      }
    })();
  }

  unlock() {
    var _this6 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this6.vault.unlock();
        console.log('vault was unlocked');
      } catch (err) {
        const msg = typeof err == 'object' ? JSON.stringify(err) : err;
        console.error('vault.service.ts unlock()', msg);
      }
    })();
  }

  useSecure(enabled) {
    var _this7 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7.config.type = enabled ? _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.SecureStorage : _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.VaultType.DeviceSecurity;
      _this7.config.deviceSecurityType = enabled ? _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.None : _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.DeviceSecurityType.Biometrics;
      yield _this7.vault.updateConfig(_this7.config);

      _this7.setData();
    })();
  }

  getData() {
    var _this8 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Get Data....');
      const data = yield _this8.vault.getValue('blar');
      console.log('Get Data', data);
      return data;
    })();
  }

  setData() {
    var _this9 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        console.log('Setting data...');
        yield _this9.vault.setValue('blar', 'test');
        console.log('Data is set');
      } catch (err) {
        console.error('vault.service.ts setData()', err);
      }
    })();
  }

  isEmpty() {
    var _this10 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this10.vault.isEmpty();
    })();
  }

  isLocked() {
    var _this11 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this11.vault.isLocked();
    })();
  }

  clear() {
    var _this12 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this12.vault.clear();
        console.log('Vault was cleared');
      } catch (err) {
        console.error('vault.service.ts clear()', err);
      }
    })();
  }

  hasBiometrics() {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _ionic_enterprise_identity_vault__WEBPACK_IMPORTED_MODULE_2__.Device.isBiometricsEnabled();
    })();
  }

}

VaultService.ɵfac = function VaultService_Factory(t) {
  return new (t || VaultService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.Platform), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController));
};

VaultService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: VaultService,
  factory: VaultService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 6824:
/*!***********************************************************!*\
  !*** ./node_modules/@ionic-enterprise/auth/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IonicAuth": () => (/* binding */ IonicAuth),
/* harmony export */   "NativeStorageProvider": () => (/* binding */ NativeStorageProvider),
/* harmony export */   "WebStorageProvider": () => (/* binding */ WebStorageProvider)
/* harmony export */ });
/* harmony import */ var _Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);


/*! Ionic Enterprise Auth Connect: https://ionicframework.com/ - Commercially Licensed */
var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};
/**
 * Check if we're required to add a port number.
 *
 * @see https://url.spec.whatwg.org/#default-port
 * @param {Number|String} port Port number we need to check
 * @param {String} protocol Protocol we need to check against.
 * @returns {Boolean} Is it a default port for the given protocol
 * @api private
 */

var requiresPort = function required(port, protocol) {
  protocol = protocol.split(':')[0];
  port = +port;
  if (!port) return false;

  switch (protocol) {
    case 'http':
    case 'ws':
      return port !== 80;

    case 'https':
    case 'wss':
      return port !== 443;

    case 'ftp':
      return port !== 21;

    case 'gopher':
      return port !== 70;

    case 'file':
      return false;
  }

  return port !== 0;
};

var has = Object.prototype.hasOwnProperty,
    undef;
/**
 * Decode a URI encoded string.
 *
 * @param {String} input The URI encoded string.
 * @returns {String|Null} The decoded string.
 * @api private
 */

function decode(input) {
  try {
    return decodeURIComponent(input.replace(/\+/g, ' '));
  } catch (e) {
    return null;
  }
}
/**
 * Attempts to encode a given input.
 *
 * @param {String} input The string that needs to be encoded.
 * @returns {String|Null} The encoded string.
 * @api private
 */


function encode(input) {
  try {
    return encodeURIComponent(input);
  } catch (e) {
    return null;
  }
}
/**
 * Simple query string parser.
 *
 * @param {String} query The query string that needs to be parsed.
 * @returns {Object}
 * @api public
 */


function querystring(query) {
  var parser = /([^=?#&]+)=?([^&]*)/g,
      result = {},
      part;

  while (part = parser.exec(query)) {
    var key = decode(part[1]),
        value = decode(part[2]); //
    // Prevent overriding of existing properties. This ensures that build-in
    // methods like `toString` or __proto__ are not overriden by malicious
    // querystrings.
    //
    // In the case if failed decoding, we want to omit the key/value pairs
    // from the result.
    //

    if (key === null || value === null || key in result) continue;
    result[key] = value;
  }

  return result;
}
/**
 * Transform a query string to an object.
 *
 * @param {Object} obj Object that should be transformed.
 * @param {String} prefix Optional prefix.
 * @returns {String}
 * @api public
 */


function querystringify(obj, prefix) {
  prefix = prefix || '';
  var pairs = [],
      value,
      key; //
  // Optionally prefix with a '?' if needed
  //

  if ('string' !== typeof prefix) prefix = '?';

  for (key in obj) {
    if (has.call(obj, key)) {
      value = obj[key]; //
      // Edge cases where we actually want to encode the value to an empty
      // string instead of the stringified value.
      //

      if (!value && (value === null || value === undef || isNaN(value))) {
        value = '';
      }

      key = encode(key);
      value = encode(value); //
      // If we failed to encode the strings, we should bail out as we don't
      // want to add invalid strings to the query.
      //

      if (key === null || value === null) continue;
      pairs.push(key + '=' + value);
    }
  }

  return pairs.length ? prefix + pairs.join('&') : '';
} //
// Expose the module.
//


var stringify = querystringify;
var parse = querystring;
var querystringify_1 = {
  stringify: stringify,
  parse: parse
};
var controlOrWhitespace = /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/,
    CRHTLF = /[\n\r\t]/g,
    slashes = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
    port = /:\d+$/,
    protocolre = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i,
    windowsDriveLetter = /^[a-zA-Z]:/;
/**
 * Remove control characters and whitespace from the beginning of a string.
 *
 * @param {Object|String} str String to trim.
 * @returns {String} A new string representing `str` stripped of control
 *     characters and whitespace from its beginning.
 * @public
 */

function trimLeft(str) {
  return (str ? str : '').toString().replace(controlOrWhitespace, '');
}
/**
 * These are the parse rules for the URL parser, it informs the parser
 * about:
 *
 * 0. The char it Needs to parse, if it's a string it should be done using
 *    indexOf, RegExp using exec and NaN means set as current value.
 * 1. The property we should set when parsing this value.
 * 2. Indication if it's backwards or forward parsing, when set as number it's
 *    the value of extra chars that should be split off.
 * 3. Inherit from location if non existing in the parser.
 * 4. `toLowerCase` the resulting value.
 */


var rules = [['#', 'hash'], // Extract from the back.
['?', 'query'], // Extract from the back.
function sanitize(address, url) {
  // Sanitize what is left of the address
  return isSpecial(url.protocol) ? address.replace(/\\/g, '/') : address;
}, ['/', 'pathname'], // Extract from the back.
['@', 'auth', 1], // Extract from the front.
[NaN, 'host', undefined, 1, 1], // Set left over value.
[/:(\d*)$/, 'port', undefined, 1], // RegExp the back.
[NaN, 'hostname', undefined, 1, 1] // Set left over.
];
/**
 * These properties should not be copied or inherited from. This is only needed
 * for all non blob URL's as a blob URL does not include a hash, only the
 * origin.
 *
 * @type {Object}
 * @private
 */

var ignore = {
  hash: 1,
  query: 1
};
/**
 * The location object differs when your code is loaded through a normal page,
 * Worker or through a worker using a blob. And with the blobble begins the
 * trouble as the location object will contain the URL of the blob, not the
 * location of the page where our code is loaded in. The actual origin is
 * encoded in the `pathname` so we can thankfully generate a good "default"
 * location from it so we can generate proper relative URL's again.
 *
 * @param {Object|String} loc Optional default location object.
 * @returns {Object} lolcation object.
 * @public
 */

function lolcation(loc) {
  var globalVar;
  if (typeof window !== 'undefined') globalVar = window;else if (typeof commonjsGlobal !== 'undefined') globalVar = commonjsGlobal;else if (typeof self !== 'undefined') globalVar = self;else globalVar = {};
  var location = globalVar.location || {};
  loc = loc || location;
  var finaldestination = {},
      type = typeof loc,
      key;

  if ('blob:' === loc.protocol) {
    finaldestination = new Url(unescape(loc.pathname), {});
  } else if ('string' === type) {
    finaldestination = new Url(loc, {});

    for (key in ignore) delete finaldestination[key];
  } else if ('object' === type) {
    for (key in loc) {
      if (key in ignore) continue;
      finaldestination[key] = loc[key];
    }

    if (finaldestination.slashes === undefined) {
      finaldestination.slashes = slashes.test(loc.href);
    }
  }

  return finaldestination;
}
/**
 * Check whether a protocol scheme is special.
 *
 * @param {String} The protocol scheme of the URL
 * @return {Boolean} `true` if the protocol scheme is special, else `false`
 * @private
 */


function isSpecial(scheme) {
  return scheme === 'file:' || scheme === 'ftp:' || scheme === 'http:' || scheme === 'https:' || scheme === 'ws:' || scheme === 'wss:';
}
/**
 * @typedef ProtocolExtract
 * @type Object
 * @property {String} protocol Protocol matched in the URL, in lowercase.
 * @property {Boolean} slashes `true` if protocol is followed by "//", else `false`.
 * @property {String} rest Rest of the URL that is not part of the protocol.
 */

/**
 * Extract protocol information from a URL with/without double slash ("//").
 *
 * @param {String} address URL we want to extract from.
 * @param {Object} location
 * @return {ProtocolExtract} Extracted information.
 * @private
 */


function extractProtocol(address, location) {
  address = trimLeft(address);
  address = address.replace(CRHTLF, '');
  location = location || {};
  var match = protocolre.exec(address);
  var protocol = match[1] ? match[1].toLowerCase() : '';
  var forwardSlashes = !!match[2];
  var otherSlashes = !!match[3];
  var slashesCount = 0;
  var rest;

  if (forwardSlashes) {
    if (otherSlashes) {
      rest = match[2] + match[3] + match[4];
      slashesCount = match[2].length + match[3].length;
    } else {
      rest = match[2] + match[4];
      slashesCount = match[2].length;
    }
  } else {
    if (otherSlashes) {
      rest = match[3] + match[4];
      slashesCount = match[3].length;
    } else {
      rest = match[4];
    }
  }

  if (protocol === 'file:') {
    if (slashesCount >= 2) {
      rest = rest.slice(2);
    }
  } else if (isSpecial(protocol)) {
    rest = match[4];
  } else if (protocol) {
    if (forwardSlashes) {
      rest = rest.slice(2);
    }
  } else if (slashesCount >= 2 && isSpecial(location.protocol)) {
    rest = match[4];
  }

  return {
    protocol: protocol,
    slashes: forwardSlashes || isSpecial(protocol),
    slashesCount: slashesCount,
    rest: rest
  };
}
/**
 * Resolve a relative URL pathname against a base URL pathname.
 *
 * @param {String} relative Pathname of the relative URL.
 * @param {String} base Pathname of the base URL.
 * @return {String} Resolved pathname.
 * @private
 */


function resolve(relative, base) {
  if (relative === '') return base;
  var path = (base || '/').split('/').slice(0, -1).concat(relative.split('/')),
      i = path.length,
      last = path[i - 1],
      unshift = false,
      up = 0;

  while (i--) {
    if (path[i] === '.') {
      path.splice(i, 1);
    } else if (path[i] === '..') {
      path.splice(i, 1);
      up++;
    } else if (up) {
      if (i === 0) unshift = true;
      path.splice(i, 1);
      up--;
    }
  }

  if (unshift) path.unshift('');
  if (last === '.' || last === '..') path.push('');
  return path.join('/');
}
/**
 * The actual URL instance. Instead of returning an object we've opted-in to
 * create an actual constructor as it's much more memory efficient and
 * faster and it pleases my OCD.
 *
 * It is worth noting that we should not use `URL` as class name to prevent
 * clashes with the global URL instance that got introduced in browsers.
 *
 * @constructor
 * @param {String} address URL we want to parse.
 * @param {Object|String} [location] Location defaults for relative paths.
 * @param {Boolean|Function} [parser] Parser for the query string.
 * @private
 */


function Url(address, location, parser) {
  address = trimLeft(address);
  address = address.replace(CRHTLF, '');

  if (!(this instanceof Url)) {
    return new Url(address, location, parser);
  }

  var relative,
      extracted,
      parse,
      instruction,
      index,
      key,
      instructions = rules.slice(),
      type = typeof location,
      url = this,
      i = 0; //
  // The following if statements allows this module two have compatibility with
  // 2 different API:
  //
  // 1. Node.js's `url.parse` api which accepts a URL, boolean as arguments
  //    where the boolean indicates that the query string should also be parsed.
  //
  // 2. The `URL` interface of the browser which accepts a URL, object as
  //    arguments. The supplied object will be used as default values / fall-back
  //    for relative paths.
  //

  if ('object' !== type && 'string' !== type) {
    parser = location;
    location = null;
  }

  if (parser && 'function' !== typeof parser) parser = querystringify_1.parse;
  location = lolcation(location); //
  // Extract protocol information before running the instructions.
  //

  extracted = extractProtocol(address || '', location);
  relative = !extracted.protocol && !extracted.slashes;
  url.slashes = extracted.slashes || relative && location.slashes;
  url.protocol = extracted.protocol || location.protocol || '';
  address = extracted.rest; //
  // When the authority component is absent the URL starts with a path
  // component.
  //

  if (extracted.protocol === 'file:' && (extracted.slashesCount !== 2 || windowsDriveLetter.test(address)) || !extracted.slashes && (extracted.protocol || extracted.slashesCount < 2 || !isSpecial(url.protocol))) {
    instructions[3] = [/(.*)/, 'pathname'];
  }

  for (; i < instructions.length; i++) {
    instruction = instructions[i];

    if (typeof instruction === 'function') {
      address = instruction(address, url);
      continue;
    }

    parse = instruction[0];
    key = instruction[1];

    if (parse !== parse) {
      url[key] = address;
    } else if ('string' === typeof parse) {
      index = parse === '@' ? address.lastIndexOf(parse) : address.indexOf(parse);

      if (~index) {
        if ('number' === typeof instruction[2]) {
          url[key] = address.slice(0, index);
          address = address.slice(index + instruction[2]);
        } else {
          url[key] = address.slice(index);
          address = address.slice(0, index);
        }
      }
    } else if (index = parse.exec(address)) {
      url[key] = index[1];
      address = address.slice(0, index.index);
    }

    url[key] = url[key] || (relative && instruction[3] ? location[key] || '' : ''); //
    // Hostname, host and protocol should be lowercased so they can be used to
    // create a proper `origin`.
    //

    if (instruction[4]) url[key] = url[key].toLowerCase();
  } //
  // Also parse the supplied query string in to an object. If we're supplied
  // with a custom parser as function use that instead of the default build-in
  // parser.
  //


  if (parser) url.query = parser(url.query); //
  // If the URL is relative, resolve the pathname against the base URL.
  //

  if (relative && location.slashes && url.pathname.charAt(0) !== '/' && (url.pathname !== '' || location.pathname !== '')) {
    url.pathname = resolve(url.pathname, location.pathname);
  } //
  // Default to a / for pathname if none exists. This normalizes the URL
  // to always have a /
  //


  if (url.pathname.charAt(0) !== '/' && isSpecial(url.protocol)) {
    url.pathname = '/' + url.pathname;
  } //
  // We should not add port numbers if they are already the default port number
  // for a given protocol. As the host also contains the port number we're going
  // override it with the hostname which contains no port number.
  //


  if (!requiresPort(url.port, url.protocol)) {
    url.host = url.hostname;
    url.port = '';
  } //
  // Parse down the `auth` for the username and password.
  //


  url.username = url.password = '';

  if (url.auth) {
    index = url.auth.indexOf(':');

    if (~index) {
      url.username = url.auth.slice(0, index);
      url.username = encodeURIComponent(decodeURIComponent(url.username));
      url.password = url.auth.slice(index + 1);
      url.password = encodeURIComponent(decodeURIComponent(url.password));
    } else {
      url.username = encodeURIComponent(decodeURIComponent(url.auth));
    }

    url.auth = url.password ? url.username + ':' + url.password : url.username;
  }

  url.origin = url.protocol !== 'file:' && isSpecial(url.protocol) && url.host ? url.protocol + '//' + url.host : 'null'; //
  // The href is just the compiled result.
  //

  url.href = url.toString();
}
/**
 * This is convenience method for changing properties in the URL instance to
 * insure that they all propagate correctly.
 *
 * @param {String} part          Property we need to adjust.
 * @param {Mixed} value          The newly assigned value.
 * @param {Boolean|Function} fn  When setting the query, it will be the function
 *                               used to parse the query.
 *                               When setting the protocol, double slash will be
 *                               removed from the final url if it is true.
 * @returns {URL} URL instance for chaining.
 * @public
 */


function set(part, value, fn) {
  var url = this;

  switch (part) {
    case 'query':
      if ('string' === typeof value && value.length) {
        value = (fn || querystringify_1.parse)(value);
      }

      url[part] = value;
      break;

    case 'port':
      url[part] = value;

      if (!requiresPort(value, url.protocol)) {
        url.host = url.hostname;
        url[part] = '';
      } else if (value) {
        url.host = url.hostname + ':' + value;
      }

      break;

    case 'hostname':
      url[part] = value;
      if (url.port) value += ':' + url.port;
      url.host = value;
      break;

    case 'host':
      url[part] = value;

      if (port.test(value)) {
        value = value.split(':');
        url.port = value.pop();
        url.hostname = value.join(':');
      } else {
        url.hostname = value;
        url.port = '';
      }

      break;

    case 'protocol':
      url.protocol = value.toLowerCase();
      url.slashes = !fn;
      break;

    case 'pathname':
    case 'hash':
      if (value) {
        var char = part === 'pathname' ? '/' : '#';
        url[part] = value.charAt(0) !== char ? char + value : value;
      } else {
        url[part] = value;
      }

      break;

    case 'username':
    case 'password':
      url[part] = encodeURIComponent(value);
      break;

    case 'auth':
      var index = value.indexOf(':');

      if (~index) {
        url.username = value.slice(0, index);
        url.username = encodeURIComponent(decodeURIComponent(url.username));
        url.password = value.slice(index + 1);
        url.password = encodeURIComponent(decodeURIComponent(url.password));
      } else {
        url.username = encodeURIComponent(decodeURIComponent(value));
      }

  }

  for (var i = 0; i < rules.length; i++) {
    var ins = rules[i];
    if (ins[4]) url[ins[1]] = url[ins[1]].toLowerCase();
  }

  url.auth = url.password ? url.username + ':' + url.password : url.username;
  url.origin = url.protocol !== 'file:' && isSpecial(url.protocol) && url.host ? url.protocol + '//' + url.host : 'null';
  url.href = url.toString();
  return url;
}
/**
 * Transform the properties back in to a valid and full URL string.
 *
 * @param {Function} stringify Optional query stringify function.
 * @returns {String} Compiled version of the URL.
 * @public
 */


function toString$1(stringify) {
  if (!stringify || 'function' !== typeof stringify) stringify = querystringify_1.stringify;
  var query,
      url = this,
      host = url.host,
      protocol = url.protocol;
  if (protocol && protocol.charAt(protocol.length - 1) !== ':') protocol += ':';
  var result = protocol + (url.protocol && url.slashes || isSpecial(url.protocol) ? '//' : '');

  if (url.username) {
    result += url.username;
    if (url.password) result += ':' + url.password;
    result += '@';
  } else if (url.password) {
    result += ':' + url.password;
    result += '@';
  } else if (url.protocol !== 'file:' && isSpecial(url.protocol) && !host && url.pathname !== '/') {
    //
    // Add back the empty userinfo, otherwise the original invalid URL
    // might be transformed into a valid one with `url.pathname` as host.
    //
    result += '@';
  } //
  // Trailing colon is removed from `url.host` when it is parsed. If it still
  // ends with a colon, then add back the trailing colon that was removed. This
  // prevents an invalid URL from being transformed into a valid one.
  //


  if (host[host.length - 1] === ':' || port.test(url.hostname) && !url.port) {
    host += ':';
  }

  result += host + url.pathname;
  query = 'object' === typeof url.query ? stringify(url.query) : url.query;
  if (query) result += '?' !== query.charAt(0) ? '?' + query : query;
  if (url.hash) result += url.hash;
  return result;
}

Url.prototype = {
  set: set,
  toString: toString$1
}; //
// Expose the URL parser and some additional properties that might be useful for
// others or testing.
//

Url.extractProtocol = extractProtocol;
Url.location = lolcation;
Url.trimLeft = trimLeft;
Url.qs = querystringify_1;
var urlParse = Url;
/**
 * @hidden
 */

class UrlInfo {
  constructor(url = undefined) {
    this.url = url;
    this.headers = undefined;
    this.payload = undefined;
  }

}

class Logger {
  constructor() {
    this.log_debug = false;
    this.log_error = true;
  }

  setLogLevel(logLevel) {
    switch (logLevel) {
      case 'DEBUG':
        this.log_debug = true;
        this.log_error = true;
        break;

      case 'ERROR':
        this.log_debug = false;
        this.log_error = true;
        break;

      case 'NONE':
        this.log_debug = false;
        this.log_error = false;
        break;

      default:
        this.log_debug = false;
        this.log_error = true;
    }
  }

  debug(...args) {
    if (this.log_debug) {
      console.log(...args);
    }
  }

  error(...args) {
    if (this.log_error) {
      console.error(...args);
    }
  }

}

const logging = new Logger();
window._ionicAuthLogging = logging;

class messages {}

messages.ADDING_COOKIES_NOT_SUPPORTED = 'auth-connect: string = "setHeader" does not support adding cookies, please use "setCookie" function instead';
messages.DATA_TYPE_MISMATCH = 'auth-connect: string = "data" argument supports only following data types:';
messages.INVALID_CLIENT_AUTH_ALIAS = 'auth-connect: string = invalid client certificate alias, needs to be a string or undefined';
messages.INVALID_CLIENT_AUTH_MODE = 'auth-connect: string = invalid client certificate authentication mode, supported modes are:';
messages.INVALID_CLIENT_AUTH_OPTIONS = 'auth-connect: string = invalid client certificate authentication options, needs to be an object';
messages.INVALID_CLIENT_AUTH_PKCS_PASSWORD = 'auth-connect: string = invalid PKCS12 container password, needs to be a string';
messages.INVALID_CLIENT_AUTH_RAW_PKCS = 'auth-connect: string = invalid PKCS12 container, needs to be an array buffer';
messages.INVALID_DATA_SERIALIZER = 'auth-connect: string = invalid serializer, supported serializers are:';
messages.INVALID_FOLLOW_REDIRECT_VALUE = 'auth-connect: string = invalid follow redirect value, needs to be a boolean value';
messages.INVALID_HEADERS_VALUE = 'auth-connect: string = header values must be strings';
messages.INVALID_HTTP_METHOD = 'auth-connect: string = invalid HTTP method, supported methods are:';
messages.INVALID_PARAMS_VALUE = 'auth-connect: string = invalid params object, needs to be an object with strings';
messages.INVALID_RESPONSE_TYPE = 'auth-connect: string = invalid response type, supported types are:';
messages.INVALID_SSL_CERT_MODE = 'auth-connect: string = invalid SSL cert mode, supported modes are:';
messages.INVALID_TIMEOUT_VALUE = 'auth-connect: string = invalid timeout value, needs to be a positive numeric value';
messages.MANDATORY_FAIL = 'auth-connect: string = missing mandatory "onFail" callback function';
messages.MANDATORY_SUCCESS = 'auth-connect: string = missing mandatory "onSuccess" callback function';
messages.LOGOUT_UNABLE_TO_RETRIEVE_TOKEN = 'auth-connect: string = Unable to retrieve Id Token from storage';

class jsUtil {
  // typeof is not working reliably in JS
  static getTypeOf(object) {
    switch (Object.prototype.toString.call(object)) {
      case '[object Array]':
        return 'Array';

      case '[object Blob]':
        return 'Blob';

      case '[object ArrayBuffer]':
        return 'ArrayBuffer';

      case '[object Boolean]':
        return 'Boolean';

      case '[object Function]':
        return 'Function';

      case '[object Null]':
        return 'Null';

      case '[object Number]':
        return 'Number';

      case '[object Object]':
        return 'Object';

      case '[object String]':
        return 'String';

      case '[object Undefined]':
        return 'Undefined';

      default:
        return 'Unknown';
    }
  }

}

class helpers {
  static mergeHeaders(globalHeaders, localHeaders) {
    var globalKeys = Object.keys(globalHeaders);
    var key;

    for (var i = 0; i < globalKeys.length; i++) {
      key = globalKeys[i];

      if (!localHeaders.hasOwnProperty(key)) {
        localHeaders[key] = globalHeaders[key];
      }
    }

    return localHeaders;
  }

  static checkForValidStringValue(list, value, onInvalidValueMessage) {
    if (jsUtil.getTypeOf(value) !== 'String') {
      throw new Error(onInvalidValueMessage + ' ' + list.join(', '));
    }

    value = value.trim().toLowerCase();

    if (list.indexOf(value) === -1) {
      throw new Error(onInvalidValueMessage + ' ' + list.join(', '));
    }

    return value;
  }

  static checkKeyValuePairObject(obj, allowedChildren, onInvalidValueMessage) {
    if (jsUtil.getTypeOf(obj) !== 'Object') {
      throw new Error(onInvalidValueMessage);
    }

    var keys = Object.keys(obj);

    for (var i = 0; i < keys.length; i++) {
      if (allowedChildren.indexOf(jsUtil.getTypeOf(obj[keys[i]])) === -1) {
        throw new Error(onInvalidValueMessage);
      }
    }

    return obj;
  }

  static checkHttpMethod(method) {
    return this.checkForValidStringValue(this.validHttpMethods, method, messages.INVALID_HTTP_METHOD);
  }

  static checkResponseType(type) {
    return this.checkForValidStringValue(this.validResponseTypes, type, messages.INVALID_RESPONSE_TYPE);
  }

  static checkSerializer(serializer) {
    return this.checkForValidStringValue(this.validSerializers, serializer, messages.INVALID_DATA_SERIALIZER);
  }

  static checkForBlacklistedHeaderKey(key) {
    if (key.toLowerCase() === 'cookie') {
      throw new Error(messages.ADDING_COOKIES_NOT_SUPPORTED);
    }

    return key;
  }

  static checkForInvalidHeaderValue(value) {
    if (jsUtil.getTypeOf(value) !== 'String') {
      throw new Error(messages.INVALID_HEADERS_VALUE);
    }

    return value;
  }

  static checkTimeoutValue(timeout) {
    if (jsUtil.getTypeOf(timeout) !== 'Number' || timeout < 0) {
      throw new Error(messages.INVALID_TIMEOUT_VALUE);
    }

    return timeout;
  }

  static checkFollowRedirectValue(follow) {
    if (jsUtil.getTypeOf(follow) !== 'Boolean') {
      throw new Error(messages.INVALID_FOLLOW_REDIRECT_VALUE);
    }

    return follow;
  }

  static checkHeadersObject(headers) {
    return this.checkKeyValuePairObject(headers, ['String'], messages.INVALID_HEADERS_VALUE);
  }

  static checkParamsObject(params) {
    return this.checkKeyValuePairObject(params, ['String', 'Array'], messages.INVALID_PARAMS_VALUE);
  }

  static getMatchingHostHeaders(url, headersList) {
    var matches = url.match(/^https?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
    var domain = matches && matches[1];
    return headersList[domain] || null;
  }

  static getMergedHeaders(url, requestHeaders, predefinedHeaders) {
    var globalHeaders = predefinedHeaders['*'] || {};
    var hostHeaders = this.getMatchingHostHeaders(url, predefinedHeaders) || {};
    var mergedHeaders = this.mergeHeaders(globalHeaders, hostHeaders);
    mergedHeaders = this.mergeHeaders(mergedHeaders, requestHeaders);
    return mergedHeaders;
  }

  static getAllowedDataTypes(dataSerializer) {
    switch (dataSerializer) {
      case 'utf8':
        return ['String'];

      case 'urlencoded':
        return ['Object'];

      default:
        return ['Array', 'Object'];
    }
  }

  static getProcessedData(data, dataSerializer) {
    var currentDataType = jsUtil.getTypeOf(data);
    var allowedDataTypes = this.getAllowedDataTypes(dataSerializer);

    if (allowedDataTypes.indexOf(currentDataType) === -1) {
      throw new Error(messages.DATA_TYPE_MISMATCH + ' ' + allowedDataTypes.join(', '));
    }

    if (dataSerializer === 'utf8') {
      data = {
        text: data
      };
    }

    return data;
  }

  static handleMissingCallbacks(successFn, failFn) {
    if (successFn === undefined) {
      throw new Error(messages.MANDATORY_SUCCESS);
    }

    if (failFn === undefined) {
      throw new Error(messages.MANDATORY_FAIL);
    }
  }

  static handleMissingOptions(options, globals) {
    options = options || {};
    return {
      method: this.checkHttpMethod(options.method || this.validHttpMethods[0]),
      responseType: this.checkResponseType(options.responseType || this.validResponseTypes[0]),
      serializer: this.checkSerializer(options.serializer || globals.serializer),
      timeout: this.checkTimeoutValue(options.timeout || globals.timeout),
      followRedirect: this.checkFollowRedirectValue(options.followRedirect || globals.followRedirect),
      headers: this.checkHeadersObject(options.headers || {}),
      params: this.checkParamsObject(options.params || {}),
      data: jsUtil.getTypeOf(options.data) === 'Undefined' ? null : options.data,
      filePath: options.filePath || '',
      name: options.name || ''
    };
  }

}

helpers.validSerializers = ['urlencoded', 'json', 'utf8'];
helpers.validHttpMethods = ['get', 'put', 'post', 'patch', 'head', 'delete', 'upload', 'download'];
helpers.validResponseTypes = ['text', 'arraybuffer', 'blob'];

class globalConfigs {}

globalConfigs.headers = {};
globalConfigs.serializer = 'urlencoded';
globalConfigs.followRedirect = true;
globalConfigs.timeout = 60.0;

class http {
  static sendRequest(url, options, success, failure) {
    helpers.handleMissingCallbacks(success, failure);
    options = helpers.handleMissingOptions(options, globalConfigs);
    var headers = helpers.getMergedHeaders(url, options.headers, globalConfigs.headers);

    switch (options.method) {
      case 'post':
      case 'put':
      case 'patch':
        var data = helpers.getProcessedData(options.data, options.serializer);
        return cordova.exec(success, failure, 'IonicHttp', options.method, [url, data, options.serializer, headers, options.timeout, options.followRedirect, options.responseType]);

      default:
        return cordova.exec(success, failure, 'IonicHttp', options.method, [url, headers, options.timeout, options.followRedirect, options.responseType]);
    }
  }

  static post(url, data, headers, success, failure) {
    return http.sendRequest(url, {
      method: 'post',
      data: data,
      headers: headers
    }, success, failure);
  }

  static get(url, success, failure) {
    return http.sendRequest(url, {
      method: 'get',
      params: {},
      headers: {}
    }, success, failure);
  }

  static put(url, data, headers, success, failure) {
    return http.sendRequest(url, {
      method: 'put',
      data: data,
      headers: headers
    }, success, failure);
  }

  static patch(url, data, headers, success, failure) {
    return http.sendRequest(url, {
      method: 'patch',
      data: data,
      headers: headers
    }, success, failure);
  }

  static del(url, params, headers, success, failure) {
    return http.sendRequest(url, {
      method: 'delete',
      params: params,
      headers: headers
    }, success, failure);
  }

  static head(url, params, headers, success, failure) {
    return http.sendRequest(url, {
      method: 'head',
      params: params,
      headers: headers
    }, success, failure);
  }

}

class UrlHelper {
  static buildUrl(url, options) {
    const params = new URLSearchParams(options);
    const urlObj = new URL(url);
    params.forEach((val, key) => urlObj.searchParams.append(key, val));
    logging.debug(urlObj.href, this.logTag, 'buildUrl: ');
    return new UrlInfo(urlObj.href);
  }

  static parseHash(urlHash) {
    let params = {};
    let queries;
    let temp;
    let i;
    let l;

    if (urlHash[0] === '#') {
      urlHash = urlHash.slice(1);
    } // Split into key/value pairs


    queries = urlHash.split('&'); // Convert the array of strings into an object

    for (i = 0, l = queries.length; i < l; i++) {
      temp = queries[i].split('=');
      params[temp[0]] = temp[1];
    }

    return params;
  }

  static post(url, data, headers) {
    logging.debug('UrlHelper::Post');
    return new Promise((resolve, reject) => {
      return http.post(url, data, headers, resolve, reject);
    });
  }

  static get(url) {
    logging.debug('UrlHelper::Post');
    return new Promise(function (resolve, reject) {
      return http.get(url, resolve, reject);
    });
  }

}

UrlHelper.logTag = 'UrlHelper: ';

class BaseStorage {
  constructor() {
    this.accessTokenKey = '_ionicAuth.accessToken';
    this.refreshTokenKey = '_ionicAuth.refreshToken';
    this.idTokenKey = '_ionicAuth.idToken';
    this.authResponseKey = '_ionicAuth.authResponse';
  }

  setClientId(clientId) {
    this.accessTokenKey = this.accessTokenKey + '.' + clientId;
    this.refreshTokenKey = this.refreshTokenKey + '.' + clientId;
    this.idTokenKey = this.idTokenKey + '.' + clientId;
    this.authResponseKey = this.authResponseKey + '.' + clientId;
  } // some keys need to be store per token, helper to ensure consistency


  formatKeyForToken(keyName, tokenName) {
    return tokenName ? this.accessTokenKey + '.' + tokenName : this.accessTokenKey;
  }

}

const isTokenStorageProvider = obj => {
  const provider = obj;
  return typeof provider === 'object' && provider.getAccessToken && typeof provider.getAccessToken === 'function' || provider.getAuthResponse && typeof provider.getAuthResponse === 'function' || provider.getIdToken && typeof provider.getIdToken === 'function' || provider.getRefreshToken && typeof provider.getRefreshToken === 'function' || provider.setAccessToken && typeof provider.setAccessToken === 'function' || provider.setAuthResponse && typeof provider.setAuthResponse === 'function' || provider.setIdToken && typeof provider.setIdToken === 'function' || provider.setRefreshToken && typeof provider.setRefreshToken === 'function' || false;
};

const isIV5UserInterface = obj => {
  const provider = obj;
  return provider.getValue && typeof provider.getValue === 'function' && provider.setValue && typeof provider.setValue === 'function' && provider.clear && typeof provider.clear === 'function' && provider.onLock && typeof provider.onLock === 'function';
};

class AuthIdentityVault5Storage extends BaseStorage {
  constructor(vault) {
    super();
    this.vault = vault;
  }
  /**
   * get the saved access token
   */


  getAccessToken(tokenName) {
    var _this = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _a;

      const key = _this.formatKeyForToken(_this.accessTokenKey, tokenName);

      logging.debug('getAccessToken key:', key);
      return (_a = yield _this.vault.getValue(key)) !== null && _a !== void 0 ? _a : undefined;
    })();
  }
  /**
   * save the access token
   */


  setAccessToken(accessToken, tokenName) {
    var _this2 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const key = _this2.formatKeyForToken(_this2.accessTokenKey, tokenName);

      logging.debug('setAccessToken: key: ', key);
      return _this2.vault.setValue(key, accessToken);
    })();
  }
  /**
   * get the saved refresh token
   */


  getRefreshToken() {
    var _this3 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _a;

      return (_a = yield _this3.vault.getValue(_this3.refreshTokenKey)) !== null && _a !== void 0 ? _a : undefined;
    })();
  }
  /**
   * save the refresh token
   */


  setRefreshToken(refreshToken) {
    var _this4 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this4.vault.setValue(_this4.refreshTokenKey, refreshToken);
    })();
  }
  /**
   * get the id token
   */


  getIdToken() {
    var _this5 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _a;

      return (_a = yield _this5.vault.getValue(_this5.idTokenKey)) !== null && _a !== void 0 ? _a : undefined;
    })();
  }
  /**
   * save the id token
   */


  setIdToken(idToken) {
    var _this6 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this6.vault.setValue(_this6.idTokenKey, idToken);
    })();
  }
  /**
   * get the full auth result
   */


  getAuthResponse() {
    var _this7 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this7.vault.getValue(_this7.authResponseKey);
    })();
  }
  /**
   * save the full auth response
   */


  setAuthResponse(response) {
    var _this8 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this8.vault.setValue(_this8.authResponseKey, response);
    })();
  }

  clear() {
    var _this9 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this9.vault.clear();
    })();
  }

  onLock(callback) {
    this.vault.onLock(callback);
  }

}

class AuthIdentityVaultStorage extends BaseStorage {
  constructor(iv) {
    super();
    this.iv = iv;
  }

  ensureVaultConfigured(setPasscodeIfNeeded) {
    var _this10 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this10.iv.getVault();
      const ivConfig = yield vault.getConfig();

      if (ivConfig.isPasscodeSetupNeeded && setPasscodeIfNeeded) {
        yield _this10.iv.setPasscode();
      }

      return vault;
    })();
  }
  /**
   * get the saved access token
   */


  getAccessToken(tokenName) {
    var _this11 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const key = _this11.formatKeyForToken(_this11.accessTokenKey, tokenName);

      logging.debug('getAccessToken: key: ', key);
      const vault = yield _this11.ensureVaultConfigured(false);
      return vault.getValue(key);
    })();
  }
  /**
   * save the access token
   */


  setAccessToken(accessToken, tokenName) {
    var _this12 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const key = _this12.formatKeyForToken(_this12.accessTokenKey, tokenName);

      logging.debug('setAccessToken: key: ', key);
      const vault = yield _this12.ensureVaultConfigured(true);
      return vault.storeValue(key, accessToken);
    })();
  }
  /**
   * get the saved refresh token
   */


  getRefreshToken() {
    var _this13 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this13.ensureVaultConfigured(false);
      return vault.getValue(_this13.refreshTokenKey);
    })();
  }
  /**
   * save the refresh token
   */


  setRefreshToken(refreshToken) {
    var _this14 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this14.ensureVaultConfigured(true);
      return vault.storeValue(_this14.refreshTokenKey, refreshToken);
    })();
  }
  /**
   * get the id token
   */


  getIdToken() {
    var _this15 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this15.ensureVaultConfigured(false);
      return vault.getValue(_this15.idTokenKey);
    })();
  }
  /**
   * save the id token
   */


  setIdToken(idToken) {
    var _this16 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this16.ensureVaultConfigured(true);
      return vault.storeValue(_this16.idTokenKey, idToken);
    })();
  }
  /**
   * get the full auth result
   */


  getAuthResponse() {
    var _this17 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this17.ensureVaultConfigured(false);
      return vault.getValue(_this17.authResponseKey);
    })();
  }
  /**
   * save the full auth response
   */


  setAuthResponse(response) {
    var _this18 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this18.ensureVaultConfigured(true);
      return vault.storeValue(_this18.authResponseKey, response);
    })();
  }

  clear() {
    var _this19 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const vault = yield _this19.iv.getVault();
      return vault.clear();
    })();
  }

}

class AuthLocalStorage extends BaseStorage {
  /**
   * get the saved access token
   */
  getAccessToken(tokenName) {
    var _this20 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const key = _this20.formatKeyForToken(_this20.accessTokenKey, tokenName);

      const accessToken = localStorage.getItem(key);
      return accessToken || undefined;
    })();
  }
  /**
   * save the access token
   */


  setAccessToken(accessToken, tokenName) {
    var _this21 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const key = _this21.formatKeyForToken(_this21.accessTokenKey, tokenName);

      return localStorage.setItem(key, accessToken);
    })();
  }
  /**
   * get the saved refresh token
   */


  getRefreshToken() {
    var _this22 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const refreshToken = localStorage.getItem(_this22.refreshTokenKey);
      return refreshToken || undefined;
    })();
  }
  /**
   * save the refresh token
   */


  setRefreshToken(refreshToken) {
    var _this23 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return localStorage.setItem(_this23.refreshTokenKey, refreshToken);
    })();
  }
  /**
   * get the id token
   */


  getIdToken() {
    var _this24 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const idToken = localStorage.getItem(_this24.idTokenKey);
      return idToken || undefined;
    })();
  }
  /**
   * save the id token
   */


  setIdToken(idToken) {
    var _this25 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return localStorage.setItem(_this25.idTokenKey, idToken);
    })();
  }
  /**
   * get the full auth result
   */


  getAuthResponse() {
    var _this26 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const authResponseString = localStorage.getItem(_this26.authResponseKey);

      if (authResponseString) {
        try {
          return JSON.parse(authResponseString);
        } catch (e) {
          logging.error(`auth response of ${authResponseString} is not valid json`);
        }
      }
    })();
  }
  /**
   * save the full auth response
   */


  setAuthResponse(response) {
    var _this27 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const authRespString = JSON.stringify(response);
        return localStorage.setItem(_this27.authResponseKey, authRespString);
      } catch (e) {}
    })();
  }

  clear() {
    var _this28 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      localStorage.removeItem(_this28.accessTokenKey);
      localStorage.removeItem(_this28.refreshTokenKey);
      localStorage.removeItem(_this28.idTokenKey);
      localStorage.removeItem(_this28.authResponseKey);
    })();
  }

}

class SessionHelper {
  constructor(clientId, storage) {
    this.authDataKey = 'ionicauth.authdata';
    this.expiresAtKey = 'ionicauth.expiresAt';
    this.nonceKey = 'ionicauth.nonce';
    this.tokenScopes = 'ionicauth.scopes';
    this.overrideUrlKey = 'ionicauth.overrideUrl';
    this.expiresAtKeys = [];
    this.tokenScopesKeys = [];
    this.authDataKey = clientId + '.' + this.authDataKey;
    this.expiresAtKey = clientId + '.' + this.expiresAtKey;
    this.nonceKey = clientId + '.' + this.nonceKey;
    this.overrideUrlKey = clientId + '.' + this.overrideUrlKey;
    this.tokenScopes = clientId + '.' + this.tokenScopes;
    this.storage = storage;
  }

  getAuthData() {
    var _this29 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const dataKey = yield _this29.storage.get(_this29.authDataKey);

      if (dataKey) {
        const session = JSON.parse(dataKey);
        return session;
      } else {
        return undefined;
      }
    })();
  }

  setAuthData(session) {
    var _this30 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this30.storage.set(_this30.authDataKey, JSON.stringify(session));
    })();
  }

  setOverrideUrl(url) {
    var _this31 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this31.storage.set(_this31.overrideUrlKey, url);
    })();
  }

  getOverrideUrl() {
    var _this32 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const overrideUrl = yield _this32.storage.get(_this32.overrideUrlKey);
      return overrideUrl ? overrideUrl : undefined;
    })();
  }

  clearOverrideUrl() {
    var _this33 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this33.storage.remove(_this33.overrideUrlKey);
    })();
  }

  clearAuthData() {
    var _this34 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this34.storage.remove(_this34.authDataKey);
    })();
  }

  getExpiresAt(tokenName) {
    var _this35 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let expiresAtKeyName = _this35.expiresAtKey;

      if (tokenName) {
        expiresAtKeyName = _this35.expiresAtKey + '.' + tokenName;
      }

      const expiresAtKey = yield _this35.storage.get(expiresAtKeyName);

      if (expiresAtKey) {
        const expiresAt = JSON.parse(expiresAtKey);
        return expiresAt;
      }

      return undefined;
    })();
  }

  setExpiresAt(expiresAt, tokenName) {
    var _this36 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let expiresAtKey = _this36.expiresAtKey;

      if (tokenName) {
        expiresAtKey = _this36.expiresAtKey + '.' + tokenName;

        _this36.tokenScopesKeys.push(expiresAtKey);
      }

      logging.debug('setExpiresAt', 'expiresAtKey', expiresAtKey);
      yield _this36.storage.set(expiresAtKey, JSON.stringify(expiresAt));
    })();
  }

  getTokenScopes(tokenName) {
    var _this37 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let tokenScopesKey = _this37.tokenScopes + '.' + tokenName;
      logging.debug('getTokenScopes', 'tokenScopes', tokenScopesKey);
      const tokenScopes = yield _this37.storage.get(tokenScopesKey);

      if (tokenScopes) {
        const expiresAt = JSON.parse(tokenScopes);
        return expiresAt;
      }

      return undefined;
    })();
  }

  setTokenScopes(scopes, tokenName) {
    var _this38 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let tokenScopesKey = _this38.tokenScopes + '.' + tokenName;

      _this38.tokenScopesKeys.push(tokenScopesKey);

      logging.debug('setTokenScopes', 'tokenScopes', tokenScopesKey);
      yield _this38.storage.set(tokenScopesKey, JSON.stringify(scopes));
    })();
  }

  clearTokenScopes() {
    var _this39 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this39.tokenScopesKeys.forEach( /*#__PURE__*/function () {
        var _ref = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (key) {
          yield _this39.storage.remove(key);
        });

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }

  clearExpiresAt() {
    var _this40 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this40.storage.remove(_this40.expiresAtKey);

      _this40.expiresAtKeys.forEach( /*#__PURE__*/function () {
        var _ref2 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (key) {
          yield _this40.storage.remove(key);
        });

        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }());
    })();
  }

  getNonce() {
    var _this41 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const nonceKey = yield _this41.storage.get(_this41.nonceKey);

      if (nonceKey) {
        const nonce = JSON.parse(nonceKey);
        return nonce;
      }

      return undefined;
    })();
  }

  setNonce(nonce) {
    var _this42 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this42.storage.set(_this42.nonceKey, JSON.stringify(nonce));
    })();
  }

  clearNonce() {
    var _this43 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this43.storage.remove(_this43.nonceKey);
    })();
  }

  clear() {
    var _this44 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this44.clearAuthData();
      yield _this44.clearExpiresAt();
      yield _this44.clearNonce();
      yield _this44.clearTokenScopes();
    })();
  }

}

var toByteArray_1 = toByteArray;
var fromByteArray_1 = fromByteArray;
var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i];
  revLookup[code.charCodeAt(i)] = i;
} // Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications


revLookup['-'.charCodeAt(0)] = 62;
revLookup['_'.charCodeAt(0)] = 63;

function getLens(b64) {
  var len = b64.length;

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4');
  } // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42


  var validLen = b64.indexOf('=');
  if (validLen === -1) validLen = len;
  var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
  return [validLen, placeHoldersLen];
}

function _byteLength(b64, validLen, placeHoldersLen) {
  return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}

function toByteArray(b64) {
  var tmp;
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
  var curByte = 0; // if there are placeholders, only get up to the last complete 4 chars

  var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
  var i;

  for (i = 0; i < len; i += 4) {
    tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
    arr[curByte++] = tmp >> 16 & 0xFF;
    arr[curByte++] = tmp >> 8 & 0xFF;
    arr[curByte++] = tmp & 0xFF;
  }

  if (placeHoldersLen === 2) {
    tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
    arr[curByte++] = tmp & 0xFF;
  }

  if (placeHoldersLen === 1) {
    tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
    arr[curByte++] = tmp >> 8 & 0xFF;
    arr[curByte++] = tmp & 0xFF;
  }

  return arr;
}

function tripletToBase64(num) {
  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
}

function encodeChunk(uint8, start, end) {
  var tmp;
  var output = [];

  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16 & 0xFF0000) + (uint8[i + 1] << 8 & 0xFF00) + (uint8[i + 2] & 0xFF);
    output.push(tripletToBase64(tmp));
  }

  return output.join('');
}

function fromByteArray(uint8) {
  var tmp;
  var len = uint8.length;
  var extraBytes = len % 3; // if we have 1 byte left, pad 2 bytes

  var parts = [];
  var maxChunkLength = 16383; // must be multiple of 3
  // go through the array every three bytes, we'll deal with trailing stuff later

  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
  } // pad the end with zeros, but make sure to not forget the extra bytes


  if (extraBytes === 1) {
    tmp = uint8[len - 1];
    parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 0x3F] + '==');
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1];
    parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 0x3F] + lookup[tmp << 2 & 0x3F] + '=');
  }

  return parts.join('');
}

const generateChallengeAndVerifier = /*#__PURE__*/function () {
  var _ref3 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (useBase64String = false) {
    const verifierPlain = getRandomCharacters(128, useBase64String);
    const verifierHashArray = yield sha256(verifierPlain);
    const challenge = base64Encode(verifierHashArray);
    logging.debug('challenge: ' + challenge);
    return {
      verifier: verifierPlain,
      challenge
    };
  });

  return function generateChallengeAndVerifier() {
    return _ref3.apply(this, arguments);
  };
}();

const getRandomNonce = () => {
  return getRandomCharacters(20);
};

const bufferToString = arrayBuffer => {
  const coder = new TextDecoder();
  return coder.decode(arrayBuffer);
};

const parseJwt = token => {
  const parts = token.split('.');
  const headerString = base64Decode(parts[0]);
  const payloadString = base64Decode(parts[1]);
  const header = JSON.parse(headerString);
  const payload = JSON.parse(payloadString);
  return {
    header,
    payload
  };
};

const base64Encode = byteArray => {
  const base64String = fromByteArray_1(byteArray);
  const urlString = escapeUrl(base64String);
  return urlString;
};

const base64Decode = encodedString => {
  const unescapedString = unescapeUrl(encodedString);
  const byteArray = toByteArray_1(unescapedString);
  const string = bufferToString(byteArray);
  return string;
};

const escapeUrl = baseString => {
  return baseString.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
};

const unescapeUrl = baseString => {
  let newString = baseString.replace(/\-/g, '+').replace(/_/g, '/'); // .replace(/\-/g, "+")
  // .replace(/_/g, "/");

  while (newString.length % 4 !== 0) {
    newString += '=';
  }

  return newString;
};
/**
 *  Secure Hash Algorithm (SHA256)
 *  http://www.webtoolkit.info/
 *  Original code by Angel Marin, Paul Johnston.
 **/


const sha256 = /*#__PURE__*/function () {
  var _sha = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (s) {
    var chrsz = 8;

    function safe_add(x, y) {
      var lsw = (x & 0xffff) + (y & 0xffff);
      var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
      return msw << 16 | lsw & 0xffff;
    }

    function S(X, n) {
      return X >>> n | X << 32 - n;
    }

    function R(X, n) {
      return X >>> n;
    }

    function Ch(x, y, z) {
      return x & y ^ ~x & z;
    }

    function Maj(x, y, z) {
      return x & y ^ x & z ^ y & z;
    }

    function Sigma0256(x) {
      return S(x, 2) ^ S(x, 13) ^ S(x, 22);
    }

    function Sigma1256(x) {
      return S(x, 6) ^ S(x, 11) ^ S(x, 25);
    }

    function Gamma0256(x) {
      return S(x, 7) ^ S(x, 18) ^ R(x, 3);
    }

    function Gamma1256(x) {
      return S(x, 17) ^ S(x, 19) ^ R(x, 10);
    }

    function core_sha256(m, l) {
      var K = new Array(0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0xfc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x6ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2);
      var HASH = new Array(0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19);
      var W = new Array(64);
      var a, b, c, d, e, f, g, h;
      var T1, T2;
      m[l >> 5] |= 0x80 << 24 - l % 32;
      m[(l + 64 >> 9 << 4) + 15] = l;

      for (var i = 0; i < m.length; i += 16) {
        a = HASH[0];
        b = HASH[1];
        c = HASH[2];
        d = HASH[3];
        e = HASH[4];
        f = HASH[5];
        g = HASH[6];
        h = HASH[7];

        for (var j = 0; j < 64; j++) {
          if (j < 16) W[j] = m[j + i];else W[j] = safe_add(safe_add(safe_add(Gamma1256(W[j - 2]), W[j - 7]), Gamma0256(W[j - 15])), W[j - 16]);
          T1 = safe_add(safe_add(safe_add(safe_add(h, Sigma1256(e)), Ch(e, f, g)), K[j]), W[j]);
          T2 = safe_add(Sigma0256(a), Maj(a, b, c));
          h = g;
          g = f;
          f = e;
          e = safe_add(d, T1);
          d = c;
          c = b;
          b = a;
          a = safe_add(T1, T2);
        }

        HASH[0] = safe_add(a, HASH[0]);
        HASH[1] = safe_add(b, HASH[1]);
        HASH[2] = safe_add(c, HASH[2]);
        HASH[3] = safe_add(d, HASH[3]);
        HASH[4] = safe_add(e, HASH[4]);
        HASH[5] = safe_add(f, HASH[5]);
        HASH[6] = safe_add(g, HASH[6]);
        HASH[7] = safe_add(h, HASH[7]);
      }

      return HASH;
    }

    function str2binb(str) {
      var bin = Array();
      var mask = (1 << chrsz) - 1;

      for (var i = 0; i < str.length * chrsz; i += chrsz) {
        bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << 24 - i % 32;
      }

      return bin;
    }

    function Utf8Encode(string) {
      string = string.replace(/\r\n/g, '\n');
      var utftext = '';

      for (var n = 0; n < string.length; n++) {
        var c = string.charCodeAt(n);

        if (c < 128) {
          utftext += String.fromCharCode(c);
        } else if (c > 127 && c < 2048) {
          utftext += String.fromCharCode(c >> 6 | 192);
          utftext += String.fromCharCode(c & 63 | 128);
        } else {
          utftext += String.fromCharCode(c >> 12 | 224);
          utftext += String.fromCharCode(c >> 6 & 63 | 128);
          utftext += String.fromCharCode(c & 63 | 128);
        }
      }

      return utftext;
    }

    function binb2hex(binarray) {
      var hex_tab = '0123456789abcdef';
      var str = '';

      for (var i = 0; i < binarray.length * 4; i++) {
        str += hex_tab.charAt(binarray[i >> 2] >> (3 - i % 4) * 8 + 4 & 0xf) + hex_tab.charAt(binarray[i >> 2] >> (3 - i % 4) * 8 & 0xf);
      }

      return str;
    }

    function hex2uint8(string) {
      var bytes = new Uint8Array(Math.ceil(string.length / 2));

      for (var i = 0; i < bytes.length; i++) bytes[i] = parseInt(string.substr(i * 2, 2), 16);

      return bytes;
    }

    s = Utf8Encode(s);
    return hex2uint8(binb2hex(core_sha256(str2binb(s), s.length * chrsz)));
  });

  function sha256(_x3) {
    return _sha.apply(this, arguments);
  }

  return sha256;
}();

const getRandomCharacters = (length, useBase64String = false) => {
  const values = useBase64String ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
  const array = new Array();

  for (let i = 0; i < length; i++) {
    array.push(values.charAt(Math.floor(Math.random() * values.length)));
  }

  return array.join('');
};

const ready$1 = new Promise(resolve => {
  const DEVICE_READY_TIMEOUT = 5000;
  const readyTimeout = setTimeout(() => {
    console.warn(`Auth Connect: deviceready did not fire within ${DEVICE_READY_TIMEOUT}ms.`);
    resolve();
  }, DEVICE_READY_TIMEOUT);
  document.addEventListener('deviceready', () => {
    clearTimeout(readyTimeout);
    resolve();
  });
});
/**
 * @hidden
 */

class IonicAuthConfig {
  constructor(options) {
    this.options = options;
    this.logTag = 'IonicAuthConfig';
    this.defaultDiscoveryUrl = '';
    this.overrideDiscoveryUrl = '';
    this.currentDiscoveryUrl = '';
    this.locations = undefined;
    logging.setLogLevel(options.logLevel);
    this.logger = logging;
  }

  generateChallengeAndVerifier() {
    return generateChallengeAndVerifier();
  }

  validateLocations() {
    if (this.locations === undefined) {
      this.logger.debug(this.logTag, 'locations undefined');
      return false;
    } // we have locations loaded are they the right ones? yep, unless we have an override


    if (this.overrideDiscoveryUrl === undefined || this.overrideDiscoveryUrl === '') {
      this.logger.debug(this.logTag, 'override discovery url empty or null');
      return true;
    }

    this.logger.debug(this.logTag, 'override discovery url: ', this.overrideDiscoveryUrl); // does the current equal the override?

    if (this.overrideDiscoveryUrl !== this.currentDiscoveryUrl) {
      this.logger.debug(this.logTag, 'override not eq current discovery url');
      return false;
    }

    this.logger.debug(this.logTag, 'all ok?');
    return true;
  }

  loadLocations() {
    var _this45 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this45.validateLocations()) {
        return;
      }

      _this45.currentDiscoveryUrl = _this45.overrideDiscoveryUrl;

      if (_this45.currentDiscoveryUrl === '') {
        _this45.currentDiscoveryUrl = _this45.options.discoveryUrl || _this45.defaultDiscoveryUrl;
      }

      _this45.logger.debug(_this45.logTag, 'discoveryUrl: ', _this45.currentDiscoveryUrl);

      if (_this45.options.platform === 'cordova' || _this45.options.platform === 'capacitor') {
        // validate?
        yield ready$1;

        try {
          const result = yield UrlHelper.get(_this45.currentDiscoveryUrl);

          _this45.logger.debug(_this45.logTag, 'result.data: ', result);

          _this45.locations = JSON.parse(result.data);
        } catch (err) {
          throw new Error(err.error);
        }
      } else {
        const resp = yield fetch(_this45.currentDiscoveryUrl);
        _this45.locations = yield resp.json(); // Transform the data into json

        _this45.logger.debug(_this45.logTag, 'locations resp: ', _this45.locations);
      }
    })();
  }

  getIssuer() {
    var _this46 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this46.loadLocations();
      return _this46.locations['issuer'];
    })();
  }

}
/** Detect free variable `global` from Node.js. */


var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;
var freeGlobal$1 = freeGlobal;
/** Detect free variable `self`. */

var freeSelf = typeof self == 'object' && self && self.Object === Object && self;
/** Used as a reference to the global object. */

var root = freeGlobal$1 || freeSelf || Function('return this')();
var root$1 = root;
/** Built-in value references. */

var Symbol = root$1.Symbol;
var Symbol$1 = Symbol;
/** Used for built-in method references. */

var objectProto$1 = Object.prototype;
/** Used to check objects for own properties. */

var hasOwnProperty = objectProto$1.hasOwnProperty;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */

var nativeObjectToString$1 = objectProto$1.toString;
/** Built-in value references. */

var symToStringTag$1 = Symbol$1 ? Symbol$1.toStringTag : undefined;
/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */

function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag$1),
      tag = value[symToStringTag$1];

  try {
    value[symToStringTag$1] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString$1.call(value);

  if (unmasked) {
    if (isOwn) {
      value[symToStringTag$1] = tag;
    } else {
      delete value[symToStringTag$1];
    }
  }

  return result;
}
/** Used for built-in method references. */


var objectProto = Object.prototype;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */

var nativeObjectToString = objectProto.toString;
/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */

function objectToString(value) {
  return nativeObjectToString.call(value);
}
/** `Object#toString` result references. */


var nullTag = '[object Null]',
    undefinedTag = '[object Undefined]';
/** Built-in value references. */

var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : undefined;
/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */

function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }

  return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
}
/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */


function isObjectLike(value) {
  return value != null && typeof value == 'object';
}
/** `Object#toString` result references. */


var symbolTag = '[object Symbol]';
/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */

function isSymbol(value) {
  return typeof value == 'symbol' || isObjectLike(value) && baseGetTag(value) == symbolTag;
}
/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */


function arrayMap(array, iteratee) {
  var index = -1,
      length = array == null ? 0 : array.length,
      result = Array(length);

  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }

  return result;
}
/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */


var isArray = Array.isArray;
var isArray$1 = isArray;
/** Used as references for various `Number` constants. */

var INFINITY = 1 / 0;
/** Used to convert symbols to primitives and strings. */

var symbolProto = Symbol$1 ? Symbol$1.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;
/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */

function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }

  if (isArray$1(value)) {
    // Recursively convert values (susceptible to call stack limits).
    return arrayMap(value, baseToString) + '';
  }

  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }

  var result = value + '';
  return result == '0' && 1 / value == -INFINITY ? '-0' : result;
}
/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */


function toString(value) {
  return value == null ? '' : baseToString(value);
}
/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */


function arrayReduce(array, iteratee, accumulator, initAccum) {
  var index = -1,
      length = array == null ? 0 : array.length;

  if (initAccum && length) {
    accumulator = array[++index];
  }

  while (++index < length) {
    accumulator = iteratee(accumulator, array[index], index, array);
  }

  return accumulator;
}
/**
 * The base implementation of `_.propertyOf` without support for deep paths.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Function} Returns the new accessor function.
 */


function basePropertyOf(object) {
  return function (key) {
    return object == null ? undefined : object[key];
  };
}
/** Used to map Latin Unicode letters to basic Latin letters. */


var deburredLetters = {
  // Latin-1 Supplement block.
  '\xc0': 'A',
  '\xc1': 'A',
  '\xc2': 'A',
  '\xc3': 'A',
  '\xc4': 'A',
  '\xc5': 'A',
  '\xe0': 'a',
  '\xe1': 'a',
  '\xe2': 'a',
  '\xe3': 'a',
  '\xe4': 'a',
  '\xe5': 'a',
  '\xc7': 'C',
  '\xe7': 'c',
  '\xd0': 'D',
  '\xf0': 'd',
  '\xc8': 'E',
  '\xc9': 'E',
  '\xca': 'E',
  '\xcb': 'E',
  '\xe8': 'e',
  '\xe9': 'e',
  '\xea': 'e',
  '\xeb': 'e',
  '\xcc': 'I',
  '\xcd': 'I',
  '\xce': 'I',
  '\xcf': 'I',
  '\xec': 'i',
  '\xed': 'i',
  '\xee': 'i',
  '\xef': 'i',
  '\xd1': 'N',
  '\xf1': 'n',
  '\xd2': 'O',
  '\xd3': 'O',
  '\xd4': 'O',
  '\xd5': 'O',
  '\xd6': 'O',
  '\xd8': 'O',
  '\xf2': 'o',
  '\xf3': 'o',
  '\xf4': 'o',
  '\xf5': 'o',
  '\xf6': 'o',
  '\xf8': 'o',
  '\xd9': 'U',
  '\xda': 'U',
  '\xdb': 'U',
  '\xdc': 'U',
  '\xf9': 'u',
  '\xfa': 'u',
  '\xfb': 'u',
  '\xfc': 'u',
  '\xdd': 'Y',
  '\xfd': 'y',
  '\xff': 'y',
  '\xc6': 'Ae',
  '\xe6': 'ae',
  '\xde': 'Th',
  '\xfe': 'th',
  '\xdf': 'ss',
  // Latin Extended-A block.
  '\u0100': 'A',
  '\u0102': 'A',
  '\u0104': 'A',
  '\u0101': 'a',
  '\u0103': 'a',
  '\u0105': 'a',
  '\u0106': 'C',
  '\u0108': 'C',
  '\u010a': 'C',
  '\u010c': 'C',
  '\u0107': 'c',
  '\u0109': 'c',
  '\u010b': 'c',
  '\u010d': 'c',
  '\u010e': 'D',
  '\u0110': 'D',
  '\u010f': 'd',
  '\u0111': 'd',
  '\u0112': 'E',
  '\u0114': 'E',
  '\u0116': 'E',
  '\u0118': 'E',
  '\u011a': 'E',
  '\u0113': 'e',
  '\u0115': 'e',
  '\u0117': 'e',
  '\u0119': 'e',
  '\u011b': 'e',
  '\u011c': 'G',
  '\u011e': 'G',
  '\u0120': 'G',
  '\u0122': 'G',
  '\u011d': 'g',
  '\u011f': 'g',
  '\u0121': 'g',
  '\u0123': 'g',
  '\u0124': 'H',
  '\u0126': 'H',
  '\u0125': 'h',
  '\u0127': 'h',
  '\u0128': 'I',
  '\u012a': 'I',
  '\u012c': 'I',
  '\u012e': 'I',
  '\u0130': 'I',
  '\u0129': 'i',
  '\u012b': 'i',
  '\u012d': 'i',
  '\u012f': 'i',
  '\u0131': 'i',
  '\u0134': 'J',
  '\u0135': 'j',
  '\u0136': 'K',
  '\u0137': 'k',
  '\u0138': 'k',
  '\u0139': 'L',
  '\u013b': 'L',
  '\u013d': 'L',
  '\u013f': 'L',
  '\u0141': 'L',
  '\u013a': 'l',
  '\u013c': 'l',
  '\u013e': 'l',
  '\u0140': 'l',
  '\u0142': 'l',
  '\u0143': 'N',
  '\u0145': 'N',
  '\u0147': 'N',
  '\u014a': 'N',
  '\u0144': 'n',
  '\u0146': 'n',
  '\u0148': 'n',
  '\u014b': 'n',
  '\u014c': 'O',
  '\u014e': 'O',
  '\u0150': 'O',
  '\u014d': 'o',
  '\u014f': 'o',
  '\u0151': 'o',
  '\u0154': 'R',
  '\u0156': 'R',
  '\u0158': 'R',
  '\u0155': 'r',
  '\u0157': 'r',
  '\u0159': 'r',
  '\u015a': 'S',
  '\u015c': 'S',
  '\u015e': 'S',
  '\u0160': 'S',
  '\u015b': 's',
  '\u015d': 's',
  '\u015f': 's',
  '\u0161': 's',
  '\u0162': 'T',
  '\u0164': 'T',
  '\u0166': 'T',
  '\u0163': 't',
  '\u0165': 't',
  '\u0167': 't',
  '\u0168': 'U',
  '\u016a': 'U',
  '\u016c': 'U',
  '\u016e': 'U',
  '\u0170': 'U',
  '\u0172': 'U',
  '\u0169': 'u',
  '\u016b': 'u',
  '\u016d': 'u',
  '\u016f': 'u',
  '\u0171': 'u',
  '\u0173': 'u',
  '\u0174': 'W',
  '\u0175': 'w',
  '\u0176': 'Y',
  '\u0177': 'y',
  '\u0178': 'Y',
  '\u0179': 'Z',
  '\u017b': 'Z',
  '\u017d': 'Z',
  '\u017a': 'z',
  '\u017c': 'z',
  '\u017e': 'z',
  '\u0132': 'IJ',
  '\u0133': 'ij',
  '\u0152': 'Oe',
  '\u0153': 'oe',
  '\u0149': "'n",
  '\u017f': 's'
};
/**
 * Used by `_.deburr` to convert Latin-1 Supplement and Latin Extended-A
 * letters to basic Latin letters.
 *
 * @private
 * @param {string} letter The matched letter to deburr.
 * @returns {string} Returns the deburred letter.
 */

var deburrLetter = basePropertyOf(deburredLetters);
var deburrLetter$1 = deburrLetter;
/** Used to match Latin Unicode letters (excluding mathematical operators). */

var reLatin = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g;
/** Used to compose unicode character classes. */

var rsComboMarksRange$1 = '\\u0300-\\u036f',
    reComboHalfMarksRange$1 = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange$1 = '\\u20d0-\\u20ff',
    rsComboRange$1 = rsComboMarksRange$1 + reComboHalfMarksRange$1 + rsComboSymbolsRange$1;
/** Used to compose unicode capture groups. */

var rsCombo$1 = '[' + rsComboRange$1 + ']';
/**
 * Used to match [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks) and
 * [combining diacritical marks for symbols](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks_for_Symbols).
 */

var reComboMark = RegExp(rsCombo$1, 'g');
/**
 * Deburrs `string` by converting
 * [Latin-1 Supplement](https://en.wikipedia.org/wiki/Latin-1_Supplement_(Unicode_block)#Character_table)
 * and [Latin Extended-A](https://en.wikipedia.org/wiki/Latin_Extended-A)
 * letters to basic Latin letters and removing
 * [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to deburr.
 * @returns {string} Returns the deburred string.
 * @example
 *
 * _.deburr('déjà vu');
 * // => 'deja vu'
 */

function deburr(string) {
  string = toString(string);
  return string && string.replace(reLatin, deburrLetter$1).replace(reComboMark, '');
}
/** Used to match words composed of alphanumeric characters. */


var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;
/**
 * Splits an ASCII `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */

function asciiWords(string) {
  return string.match(reAsciiWord) || [];
}
/** Used to detect strings that need a more robust regexp to match words. */


var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;
/**
 * Checks if `string` contains a word composed of Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a word is found, else `false`.
 */

function hasUnicodeWord(string) {
  return reHasUnicodeWord.test(string);
}
/** Used to compose unicode character classes. */


var rsAstralRange = '\\ud800-\\udfff',
    rsComboMarksRange = '\\u0300-\\u036f',
    reComboHalfMarksRange = '\\ufe20-\\ufe2f',
    rsComboSymbolsRange = '\\u20d0-\\u20ff',
    rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange,
    rsDingbatRange = '\\u2700-\\u27bf',
    rsLowerRange = 'a-z\\xdf-\\xf6\\xf8-\\xff',
    rsMathOpRange = '\\xac\\xb1\\xd7\\xf7',
    rsNonCharRange = '\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf',
    rsPunctuationRange = '\\u2000-\\u206f',
    rsSpaceRange = ' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000',
    rsUpperRange = 'A-Z\\xc0-\\xd6\\xd8-\\xde',
    rsVarRange = '\\ufe0e\\ufe0f',
    rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;
/** Used to compose unicode capture groups. */

var rsApos$1 = "['\u2019]",
    rsBreak = '[' + rsBreakRange + ']',
    rsCombo = '[' + rsComboRange + ']',
    rsDigits = '\\d+',
    rsDingbat = '[' + rsDingbatRange + ']',
    rsLower = '[' + rsLowerRange + ']',
    rsMisc = '[^' + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + ']',
    rsFitz = '\\ud83c[\\udffb-\\udfff]',
    rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')',
    rsNonAstral = '[^' + rsAstralRange + ']',
    rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}',
    rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]',
    rsUpper = '[' + rsUpperRange + ']',
    rsZWJ = '\\u200d';
/** Used to compose unicode regexes. */

var rsMiscLower = '(?:' + rsLower + '|' + rsMisc + ')',
    rsMiscUpper = '(?:' + rsUpper + '|' + rsMisc + ')',
    rsOptContrLower = '(?:' + rsApos$1 + '(?:d|ll|m|re|s|t|ve))?',
    rsOptContrUpper = '(?:' + rsApos$1 + '(?:D|LL|M|RE|S|T|VE))?',
    reOptMod = rsModifier + '?',
    rsOptVar = '[' + rsVarRange + ']?',
    rsOptJoin = '(?:' + rsZWJ + '(?:' + [rsNonAstral, rsRegional, rsSurrPair].join('|') + ')' + rsOptVar + reOptMod + ')*',
    rsOrdLower = '\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])',
    rsOrdUpper = '\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])',
    rsSeq = rsOptVar + reOptMod + rsOptJoin,
    rsEmoji = '(?:' + [rsDingbat, rsRegional, rsSurrPair].join('|') + ')' + rsSeq;
/** Used to match complex or compound words. */

var reUnicodeWord = RegExp([rsUpper + '?' + rsLower + '+' + rsOptContrLower + '(?=' + [rsBreak, rsUpper, '$'].join('|') + ')', rsMiscUpper + '+' + rsOptContrUpper + '(?=' + [rsBreak, rsUpper + rsMiscLower, '$'].join('|') + ')', rsUpper + '?' + rsMiscLower + '+' + rsOptContrLower, rsUpper + '+' + rsOptContrUpper, rsOrdUpper, rsOrdLower, rsDigits, rsEmoji].join('|'), 'g');
/**
 * Splits a Unicode `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */

function unicodeWords(string) {
  return string.match(reUnicodeWord) || [];
}
/**
 * Splits `string` into an array of its words.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to inspect.
 * @param {RegExp|string} [pattern] The pattern to match words.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the words of `string`.
 * @example
 *
 * _.words('fred, barney, & pebbles');
 * // => ['fred', 'barney', 'pebbles']
 *
 * _.words('fred, barney, & pebbles', /[^, ]+/g);
 * // => ['fred', 'barney', '&', 'pebbles']
 */


function words(string, pattern, guard) {
  string = toString(string);
  pattern = guard ? undefined : pattern;

  if (pattern === undefined) {
    return hasUnicodeWord(string) ? unicodeWords(string) : asciiWords(string);
  }

  return string.match(pattern) || [];
}
/** Used to compose unicode capture groups. */


var rsApos = "['\u2019]";
/** Used to match apostrophes. */

var reApos = RegExp(rsApos, 'g');
/**
 * Creates a function like `_.camelCase`.
 *
 * @private
 * @param {Function} callback The function to combine each word.
 * @returns {Function} Returns the new compounder function.
 */

function createCompounder(callback) {
  return function (string) {
    return arrayReduce(words(deburr(string).replace(reApos, '')), callback, '');
  };
}
/**
 * Converts `string` to
 * [snake case](https://en.wikipedia.org/wiki/Snake_case).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the snake cased string.
 * @example
 *
 * _.snakeCase('Foo Bar');
 * // => 'foo_bar'
 *
 * _.snakeCase('fooBar');
 * // => 'foo_bar'
 *
 * _.snakeCase('--FOO-BAR--');
 * // => 'foo_bar'
 */


var snakeCase = createCompounder(function (result, word, index) {
  return result + (index ? '_' : '') + word.toLowerCase();
});
var snakeCase$1 = snakeCase;
var validAuthorizationParams = ['acr_values', 'audience', 'claims', 'claims_locales', 'client_id', 'client_secret', 'code_challenge', 'code_challenge_method', 'domain_hint', 'display', 'id_token_hint', 'login_hint', 'logout_uri', 'max_age', 'nonce', 'post_logout_redirect_uri', 'prompt', 'redirect_uri', 'registration', 'request', 'request_uri', 'response_mode', 'response_type', 'return_to', 'scope', 'state', 'ui_locales', 'vtr'];

class OAuthPacker {
  static packParams(options) {
    const validParams = {};

    for (let key in options) {
      if (!options[key]) continue; // skip null/undefined/empty string values

      const snakedKey = snakeCase$1(key);

      if (validAuthorizationParams.includes(snakedKey)) {
        validParams[snakedKey] = options[key];
      } else {
        logging.debug('OAuthPacker::packParams', 'adding additional param:', key);
        validParams[key] = options[key];
      }
    }

    return validParams;
  }

}

class IonicAuth0Config extends IonicAuthConfig {
  constructor(options) {
    super(options);
    this.options = options;

    if (options.discoveryUrl == undefined) {
      throw "IonicAuthOptions.discoveryUrl must be defined for Auth0, it usually is 'https://YOUR_DOMAIN/.well-known/openid-configuration'";
    }
  }

  loadLocations() {
    var _superprop_getLoadLocations = () => super.loadLocations,
        _this47 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _superprop_getLoadLocations().call(_this47);

      if (_this47.locations['logout_endpoint'] == undefined) {
        _this47.locations['logout_endpoint'] = _this47.locations['issuer'] + 'logout';
      }
    })();
  }

  getAuthorizeUrl(nonce, challenge, parameters) {
    var _this48 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this48.loadLocations();
      const base = Object.assign(Object.assign({}, parameters), {
        clientId: _this48.options.clientID,
        redirectUri: _this48.options.redirectUri,
        audience: _this48.options.audience,
        nonce: nonce,
        state: nonce,
        scope: _this48.options.scope
      });
      const PKCE = {
        code_challenge_method: 'S256',
        code_challenge: challenge,
        responseType: 'code'
      };

      if (_this48.options.platform !== 'web') {
        const options = Object.assign(Object.assign({}, base), PKCE);
        return UrlHelper.buildUrl(_this48.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      } else {
        // web case
        const webBase = Object.assign(Object.assign({}, base), {
          client_secret: _this48.options.clientSecret
        });
        let options = {};

        if (_this48.options.webAuthFlow && _this48.options.webAuthFlow === 'PKCE') {
          options = Object.assign(Object.assign({}, webBase), PKCE);
        } else {
          options = Object.assign(Object.assign({}, webBase), {
            response_type: 'id_token token',
            response_mode: 'fragment'
          });
        }

        return UrlHelper.buildUrl(_this48.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      }
    })();
  }

  getLogoutUrl() {
    var _this49 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this49.loadLocations();
      const options = {
        clientId: _this49.options.clientID
      };
      let params = OAuthPacker.packParams(options);
      params['returnTo'] = _this49.options.logoutUrl;
      let logoutUrl = UrlHelper.buildUrl(_this49.locations['logout_endpoint'], params);
      return logoutUrl;
    })();
  }

  getTokenUrl() {
    var _this50 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this50.loadLocations();
      return {
        url: _this50.locations['token_endpoint'],
        headers: {},
        payload: {}
      };
    })();
  }

}

class IonicAzureConfig extends IonicAuthConfig {
  constructor(options) {
    super(options);
    this.options = options;
    this.defaultDiscoveryUrl = 'https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration';
  }

  getAuthorizeUrl(nonce, challenge, parameters) {
    var _this51 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this51.loadLocations();
      const base = Object.assign(Object.assign({}, parameters), {
        clientId: _this51.options.clientID,
        redirectUri: _this51.options.redirectUri,
        audience: _this51.options.audience,
        nonce: nonce,
        state: nonce,
        scope: _this51.options.scope
      });

      if (_this51.options.platform != 'web') {
        const options = Object.assign(Object.assign({}, base), {
          code_challenge_method: 'S256',
          code_challenge: challenge,
          responseType: 'code'
        });
        return UrlHelper.buildUrl(_this51.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      } else {
        // web case
        let options = {};

        if (_this51.options.webAuthFlow && _this51.options.webAuthFlow === 'PKCE') {
          options = Object.assign(Object.assign({}, base), {
            code_challenge_method: 'S256',
            code_challenge: challenge,
            responseType: 'code'
          });
        } else {
          options = Object.assign(Object.assign({}, base), {
            response_type: 'id_token token',
            response_mode: 'fragment',
            client_secret: _this51.options.clientSecret
          });
        }

        return UrlHelper.buildUrl(_this51.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      }
    })();
  }

  getLogoutUrl() {
    var _this52 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this52.loadLocations();
      const options = {
        clientId: _this52.options.clientID,
        returnTo: _this52.options.redirectUri,
        redirectUri: _this52.options.redirectUri,
        postLogoutRedirectUri: _this52.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this52.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

  getTokenUrl() {
    var _this53 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this53.loadLocations();
      return {
        url: _this53.locations['token_endpoint'],
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json'
        },
        payload: {
          scope: String(_this53.options.scope)
        }
      };
    })();
  }

}

class IonicCognitoConfig extends IonicAuthConfig {
  constructor(options) {
    super(options);
    this.options = options; // validate that client_id and client_secret are set

    if (this.options.discoveryUrl == undefined) {
      throw "IonicAuthOptions.discoveryUrl must be defined for Cognito, it usually is 'https://cognito-idp.REGION.amazonaws.com/USER-POOL-ID'";
    }
  }

  loadLocations() {
    var _superprop_getLoadLocations2 = () => super.loadLocations,
        _this54 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _superprop_getLoadLocations2().call(_this54);

      if (_this54.locations['logout_endpoint'] == undefined) {
        const auth_endpoint = _this54.locations['authorization_endpoint'] || '';
        const url = new URL(auth_endpoint);
        url.pathname = 'logout';
        _this54.locations['logout_endpoint'] = url.href;
      }
    })();
  }

  getAuthorizeUrl(nonce, challenge, parameters) {
    var _this55 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this55.loadLocations();
      const base = Object.assign(Object.assign({}, parameters), {
        clientId: _this55.options.clientID,
        redirectUri: _this55.options.redirectUri,
        audience: _this55.options.audience,
        nonce: nonce,
        state: nonce,
        scope: _this55.options.scope
      });
      const PKCE = Object.assign(Object.assign({}, base), {
        code_challenge_method: 'S256',
        code_challenge: challenge,
        responseType: 'code'
      });

      if (_this55.options.platform !== 'web') {
        const options = Object.assign({}, PKCE);
        return UrlHelper.buildUrl(_this55.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      } else {
        // web case
        let options = {};

        if (_this55.options.webAuthFlow && _this55.options.webAuthFlow === 'PKCE') {
          options = Object.assign({}, PKCE);
        } else {
          options = Object.assign(Object.assign({}, base), {
            response_type: 'token',
            response_mode: 'fragment'
          });
        }

        return UrlHelper.buildUrl(_this55.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      }
    })();
  }

  getLogoutUrl() {
    var _this56 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this56.loadLocations();
      const options = {
        clientId: _this56.options.clientID,
        logoutUri: _this56.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this56.locations['logout_endpoint'], OAuthPacker.packParams(options));
    })();
  }

  getTokenUrl() {
    var _this57 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this57.loadLocations();
      const headers = {};

      if (_this57.options.clientSecret) {
        const auth_header = base64Encode(new TextEncoder().encode(`${_this57.options.clientID}:${_this57.options.clientSecret}`));
        headers['Authorization'] = `Basic ${auth_header}`;
      }

      return {
        url: _this57.locations['token_endpoint'],
        headers,
        payload: {}
      };
    })();
  }

}

class IonicGeneralAuthConfig extends IonicAuthConfig {
  constructor(options) {
    super(options);
    this.options = options;

    if (options.discoveryUrl == undefined) {
      throw "IonicAuthOptions.discoveryUrl must be defined, it usually is 'https://YOUR_DOMAIN/.well-known/openid-configuration'";
    }
  }

  loadLocations() {
    var _superprop_getLoadLocations3 = () => super.loadLocations,
        _this58 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _superprop_getLoadLocations3().call(_this58);

      if (_this58.locations['logout_endpoint'] == undefined) {
        const issuer = _this58.locations['issuer'];
        _this58.locations['logout_endpoint'] = issuer.endsWith('/') ? `${issuer}logout` : `${issuer}/logout`;
      }
    })();
  }

  getAuthorizeUrl(nonce, challenge, parameters) {
    var _this59 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this59.loadLocations();
      const base = Object.assign(Object.assign({}, parameters), {
        clientId: _this59.options.clientID,
        redirectUri: _this59.options.redirectUri,
        audience: _this59.options.audience,
        nonce: nonce,
        state: nonce,
        scope: _this59.options.scope
      });
      const PKCE = {
        code_challenge_method: 'S256',
        code_challenge: challenge,
        responseType: 'code'
      };

      if (_this59.options.platform !== 'web') {
        const options = Object.assign(Object.assign({}, base), PKCE);
        return UrlHelper.buildUrl(_this59.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      } else {
        // web case
        const webBase = Object.assign(Object.assign({}, base), {
          client_secret: _this59.options.clientSecret
        });
        let options = {};

        if (_this59.options.webAuthFlow && _this59.options.webAuthFlow === 'PKCE') {
          options = Object.assign(Object.assign({}, webBase), PKCE);
        } else {
          options = Object.assign(Object.assign({}, webBase), {
            response_type: 'id_token token',
            response_mode: 'fragment'
          });
        }

        return UrlHelper.buildUrl(_this59.locations['authorization_endpoint'], OAuthPacker.packParams(options));
      }
    })();
  }

  getLogoutUrl() {
    var _this60 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this60.loadLocations();
      const options = {
        clientId: _this60.options.clientID
      };
      let params = OAuthPacker.packParams(options);
      params['returnTo'] = _this60.options.logoutUrl;
      let logoutUrl = UrlHelper.buildUrl(_this60.locations['end_session_endpoint'] || _this60.locations['logout_endpoint'], params);
      return logoutUrl;
    })();
  }

  getTokenUrl() {
    var _this61 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this61.loadLocations();
      const generalConfig = _this61.options;
      let payload = {}; // defaults to true

      if (generalConfig.alwaysSendClientSecretOnLogin !== false && !!generalConfig.clientSecret) {
        payload = {
          client_secret: generalConfig.clientSecret
        };
      }

      return {
        url: _this61.locations['token_endpoint'],
        headers: {},
        payload: payload
      };
    })();
  }

}

class IonicSalesForceAuthConfig extends IonicGeneralAuthConfig {
  // The only unique salesforce quirk is that the challenge/verifier can only consist of hexidecimal chars
  generateChallengeAndVerifier() {
    return generateChallengeAndVerifier(true);
  }

  getLogoutUrl() {
    var _this62 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this62.loadLocations();
      const options = {
        clientId: _this62.options.clientID,
        postLogoutRedirectUri: _this62.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this62.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}

class IonicPingAuthConfig extends IonicGeneralAuthConfig {
  getLogoutUrl() {
    var _this63 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this63.loadLocations();
      const options = {
        clientId: _this63.options.clientID,
        redirectUri: _this63.options.redirectUri
      };
      return UrlHelper.buildUrl(_this63.locations['ping_end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}

class IonicOneLoginConfig extends IonicGeneralAuthConfig {
  constructor(options, onGetRawIdToken) {
    super(options);
    this.onGetRawIdToken = onGetRawIdToken;
  }

  getLogoutUrl() {
    var _this64 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this64.loadLocations();
      let token;

      try {
        token = yield _this64.onGetRawIdToken();
      } catch (e) {
        throw new Error(messages.LOGOUT_UNABLE_TO_RETRIEVE_TOKEN);
      }

      const options = {
        postLogoutRedirectUri: _this64.options.logoutUrl,
        idTokenHint: token
      };
      return UrlHelper.buildUrl(_this64.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}

class IonicOktaAuthConfig extends IonicGeneralAuthConfig {
  constructor(options, onGetRawIdToken) {
    super(options);
    this.onGetRawIdToken = onGetRawIdToken;
  } // OKTA doesn't have a logout_endpoint in their config, rather they use end_session_endpoint


  getLogoutUrl() {
    var _this65 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this65.loadLocations();
      let token;

      try {
        token = yield _this65.onGetRawIdToken();
      } catch (e) {
        throw new Error(messages.LOGOUT_UNABLE_TO_RETRIEVE_TOKEN);
      }

      const options = {
        idTokenHint: token,
        postLogoutRedirectUri: _this65.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this65.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}

class IdentityServerAuthConfig extends IonicGeneralAuthConfig {
  constructor(options, onGetRawIdToken) {
    super(options);
    this.onGetRawIdToken = onGetRawIdToken;
  } // IdentityServer doesn't have a logout_endpoint in their config, rather they use end_session_endpoint


  getLogoutUrl() {
    var _this66 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this66.loadLocations();
      let token;

      try {
        token = yield _this66.onGetRawIdToken();
      } catch (e) {
        throw new Error(messages.LOGOUT_UNABLE_TO_RETRIEVE_TOKEN);
      }

      const options = {
        idTokenHint: token,
        postLogoutRedirectUri: _this66.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this66.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}

class IonicKeyCloakConfig extends IonicGeneralAuthConfig {
  // The only unique salesforce quirk is that the challenge/verifier can only consist of hexidecimal chars
  getLogoutUrl() {
    var _this67 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this67.loadLocations();
      const options = {
        clientId: _this67.options.clientID,
        postLogoutRedirectUri: _this67.options.logoutUrl
      };
      return UrlHelper.buildUrl(_this67.locations['end_session_endpoint'], OAuthPacker.packParams(options));
    })();
  }

}
/**
 * @hidden
 */


class WebStorageProvider {
  constructor(keyPrefix = 'ionic-ac-storage:') {
    this.keyPrefix = keyPrefix;
  }

  get(key) {
    var _this68 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return localStorage.getItem(_this68.getKey(key));
    })();
  }

  set(key, value) {
    var _this69 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return localStorage.setItem(_this69.getKey(key), value);
    })();
  }

  remove(key) {
    var _this70 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return localStorage.removeItem(_this70.getKey(key));
    })();
  }

  clear() {
    var _this71 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      var _a;

      const length = localStorage.length;

      for (let i = 0; i < length; i++) {
        if ((_a = localStorage.key(i)) === null || _a === void 0 ? void 0 : _a.startsWith(_this71.keyPrefix)) {
          localStorage.removeItem(localStorage.key(i));
        }
      }
    })();
  }

  getKey(key) {
    return `${this.keyPrefix}${key}`;
  }

}
/**
 * @hidden
 */


class NativeStorageProvider {
  get(key) {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((res, rej) => {
        cordova.exec(function (result) {
          res(result);
        }, function (error) {
          rej(error);
        }, 'IonicAuthConnectStorage', 'get', [key]);
      });
    })();
  }

  set(key, value) {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((res, rej) => {
        cordova.exec(function (_winParam) {
          res();
        }, function (error) {
          rej(error);
        }, 'IonicAuthConnectStorage', 'set', [key, value]);
      });
    })();
  }

  remove(key) {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((res, rej) => {
        cordova.exec(function () {
          res();
        }, function (error) {
          rej(error);
        }, 'IonicAuthConnectStorage', 'remove', [key]);
      });
    })();
  }

  clear() {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((res, rej) => {
        cordova.exec(function () {
          res();
        }, function (error) {
          rej(error);
        }, 'IonicAuthConnectStorage', 'clear');
      });
    })();
  }

}

class IonicBaseAuth {
  constructor(options, handlers) {
    var _this72 = this;

    this.options = options;
    this.handlers = handlers;
    this.logTag = 'IonicBaseAuth: ';
    this.addedLoginParameters = {};
    this.storage = this.getStorageProvider(options.tokenStorageProvider);
    this.session = new SessionHelper(options.clientID, this.options.platform === 'web' ? new WebStorageProvider() : new NativeStorageProvider());
    logging.setLogLevel(options.logLevel);
    this.logger = logging;

    switch (this.options.authConfig) {
      case 'auth0':
        this.authConfig = new IonicAuth0Config(options);
        break;

      case 'azure':
        this.authConfig = new IonicAzureConfig(options);
        break;

      case 'cognito':
        this.authConfig = new IonicCognitoConfig(options);
        break;

      case 'general':
        this.authConfig = new IonicGeneralAuthConfig(options);
        break;

      case 'salesforce':
        this.authConfig = new IonicSalesForceAuthConfig(options);
        break;

      case 'ping':
        this.authConfig = new IonicPingAuthConfig(options);
        break;

      case 'identity-server':
        this.authConfig = new IdentityServerAuthConfig(options, /*#__PURE__*/(0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          return _this72.getRawIdToken();
        }));
        break;

      case 'okta':
        this.authConfig = new IonicOktaAuthConfig(options, /*#__PURE__*/(0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          return _this72.getRawIdToken();
        }));
        break;

      case 'keycloak':
        this.authConfig = new IonicKeyCloakConfig(options);
        break;

      case 'onelogin':
        this.authConfig = new IonicOneLoginConfig(options, /*#__PURE__*/(0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          return _this72.getRawIdToken();
        }));
        break;

      default:
        this.authConfig = new IonicAzureConfig(options);
        break;
    }
  }

  getRawIdToken() {
    var _this73 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let idToken = undefined;

      if (_this73.storage.getIdToken) {
        idToken = yield _this73.storage.getIdToken();
      } else {
        idToken = _this73.authResult && _this73.authResult.idToken;
      }

      return idToken;
    })();
  }

  setStorageOnLockCallback(onLockCallback) {
    if (this.storage.onLock && typeof this.storage.onLock === 'function') {
      this.storage.onLock(onLockCallback);
    }
  }

  getStorageProvider(type) {
    if (!type || type === 'localStorage') {
      const authLocalStorage = new AuthLocalStorage();
      authLocalStorage.setClientId(this.options.clientID);
      return authLocalStorage;
    } else if (isTokenStorageProvider(type)) {
      return type;
    } else if (isIV5UserInterface(type)) {
      const authIV5Storage = new AuthIdentityVault5Storage(type);
      authIV5Storage.setClientId(this.options.clientID);
      return authIV5Storage;
    } else {
      const authIVStorage = new AuthIdentityVaultStorage(type);
      authIVStorage.setClientId(this.options.clientID);
      return authIVStorage;
    }
  }

  validateIdToken(idToken) {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return parseJwt(idToken).payload;
    })();
  }

  setSession(authResult, tokenName, scopes) {
    var _this74 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const expiresAt = authResult.expiresIn ? authResult.expiresIn * 1000 + new Date().getTime() : undefined;

      if (expiresAt) {
        _this74.logger.debug('setting expires at', expiresAt);

        yield _this74.session.setExpiresAt(expiresAt, tokenName);
      } else {
        _this74.logger.debug('no expiration sent in result');
      } // if we have a valid tokenName we are refreshing a secondary token
      //   save the scopes, but not the result


      if (tokenName) {
        yield _this74.session.setTokenScopes(scopes, tokenName);
      } else {
        _this74.authResult = authResult;
      }

      if (_this74.storage.setIdToken && authResult.idToken) {
        yield _this74.storage.setIdToken(authResult.idToken);
      }

      if (_this74.storage.setAccessToken && authResult.accessToken) {
        yield _this74.storage.setAccessToken(authResult.accessToken, tokenName);
      }

      if (_this74.storage.setRefreshToken && authResult.refreshToken) {
        yield _this74.storage.setRefreshToken(authResult.refreshToken);
      }

      return _this74.authResult;
    })();
  }

  additionalLoginParameters(parameters) {
    this.addedLoginParameters = parameters;
  }

  setOverrideDiscoveryUrl(url) {
    var _this75 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this75.authConfig.overrideDiscoveryUrl = url;
      yield _this75.session.setOverrideUrl(url);
    })();
  }

  clearOverrideDiscoveryUrl() {
    var _this76 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this76.authConfig.overrideDiscoveryUrl = '';
      yield _this76.session.clearOverrideUrl();
    })();
  }

  getOverrideDiscoveryUrl() {
    var _this77 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this77.authConfig.overrideDiscoveryUrl = (yield _this77.session.getOverrideUrl()) || '';
      return _this77.authConfig.overrideDiscoveryUrl || undefined;
    })();
  }

  getAccessTokenExpiration(tokenName) {
    var _this78 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const expiresAt = yield _this78.session.getExpiresAt(tokenName);
      return typeof expiresAt === 'number' ? expiresAt : undefined;
    })();
  }

  login(overrideUrl) {
    var _this79 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise( /*#__PURE__*/function () {
        var _ref7 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (resolve, reject) {
          const keys = yield _this79.authConfig.generateChallengeAndVerifier();
          const nonce = getRandomNonce();
          yield _this79.session.clearAuthData();
          yield _this79.session.setAuthData(keys);
          yield _this79.session.setNonce(nonce);
          const previousOverrideUrl = yield _this79.session.getOverrideUrl();
          _this79.authConfig.overrideDiscoveryUrl = overrideUrl || previousOverrideUrl || '';

          try {
            const url = yield _this79.authConfig.getAuthorizeUrl(nonce, keys.challenge, _this79.addedLoginParameters);

            _this79.showUrl(url.url, undefined, _this79.options.redirectUri).then( /*#__PURE__*/function () {
              var _ref8 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (result) {
                const callbackString = result.callback;

                if (callbackString) {
                  const searchParams = new URL(callbackString).searchParams;

                  if (searchParams.has('error_description')) {
                    const errorDescription = searchParams.get('error_description');
                    logging.debug('error_description' + errorDescription);
                    throw new Error(errorDescription);
                  }

                  const authResult = yield _this79.internalHandleCallback(callbackString, false);

                  _this79.onLoginSuccess(authResult);

                  resolve();
                } else {
                  if (result.event === 'closed') {
                    throw new Error('browser was closed');
                  } else {
                    throw new Error('no callback string');
                  }
                }
              });

              return function (_x6) {
                return _ref8.apply(this, arguments);
              };
            }()).catch(error => {
              reject(error);
            });
          } catch (err) {
            reject(err);
          }
        });

        return function (_x4, _x5) {
          return _ref7.apply(this, arguments);
        };
      }());
    })();
  }

  getIdToken() {
    var _this80 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const idToken = yield _this80.getRawIdToken();

      if (!idToken) {
        return;
      }

      const result = yield _this80.validateIdToken(idToken);
      return result;
    })();
  }

  getAuthResponse() {
    var _this81 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this81.storage.getAuthResponse) {
        return _this81.storage.getAuthResponse();
      }
    })();
  }

  handleLoginCallback(url = window.location.href) {
    var _this82 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const authResult = yield _this82.internalHandleCallback(url, true);

      _this82.onLoginSuccess(authResult);

      return authResult;
    })();
  }

  handleLogoutCallback() {
    var _this83 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this83.finishLogout();
    })();
  }
  /**
   * @deprecated Use `handleLoginCallback()` instead
   */


  handleCallback(url) {
    var _this84 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this84.handleLoginCallback(url);
    })();
  }

  isAccessTokenAvailable(tokenName) {
    var _this85 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this85.storage.getAccessToken) {
        const token = yield _this85.storage.getAccessToken(tokenName);
        return !!token;
      }

      return false;
    })();
  }

  isAccessTokenExpired(tokenName) {
    var _this86 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const expiresAt = yield _this86.session.getExpiresAt(tokenName);

      _this86.logger.debug(_this86.logTag, 'expiresAt: ', expiresAt); // If the result didn't include an expires_in we can't know whether it's expired or not


      return typeof expiresAt === 'number' ? new Date().getTime() >= expiresAt : false;
    })();
  }

  isAuthenticated(tokenName) {
    var _this87 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const idToken = yield _this87.getIdToken();

      if (!idToken) {
        _this87.logger.debug(_this87.logTag, 'no idToken, false');

        return false;
      }

      try {
        let isAuthenticated = !(yield _this87.isAccessTokenExpired(tokenName));

        if (!isAuthenticated) {
          _this87.logger.debug(_this87.logTag, 'after expiresAt time');

          try {
            yield _this87.refreshSession(tokenName);

            _this87.logger.debug(_this87.logTag, 'refresh succeeded, returning true');

            isAuthenticated = true;
          } catch (e) {
            yield _this87.clearStorage();

            _this87.logger.debug(_this87.logTag, 'refresh threw, false', e);

            isAuthenticated = false;
          }
        }

        return isAuthenticated;
      } catch (e) {
        _this87.logger.error(`${_this87.logTag} isAuthenticated`, e);

        yield _this87.clearStorage();
        return false;
      }
    })();
  }

  getRefreshToken() {
    var _this88 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this88.storage.getRefreshToken ? yield _this88.storage.getRefreshToken() : undefined;
    })();
  }

  isRefreshTokenAvailable() {
    var _this89 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return !!(yield _this89.getRefreshToken());
    })();
  }

  internalGetToken(codeName, code, grantType, verifier, scope) {
    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      throw Error('Not Implemented');
    })();
  }

  getAccessToken(tokenName, scopes) {
    var _this90 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const isAuthenticated = yield _this90.isAuthenticated();

      if (!isAuthenticated) {
        _this90.logger.debug(_this90.logTag, 'Not authenticated, refresh failed.');

        throw 'Not authenticated, refresh failed.';
      }

      if (_this90.storage.getAccessToken) {
        _this90.logger.debug(_this90.logTag, 'returning storage accessToken', tokenName);

        if (tokenName) {
          const tempAccessToken = yield _this90.storage.getAccessToken(tokenName);

          if (tempAccessToken) {
            const isAuthenticatedToken = yield _this90.isAuthenticated(tokenName);

            if (!isAuthenticatedToken) {
              _this90.logger.debug(_this90.logTag, 'Not authenticated, refresh2 failed.');

              throw 'Not authenticated, refresh2 failed.';
            }
          }
        }

        const accessToken = yield _this90.storage.getAccessToken(tokenName);

        if (accessToken) {
          return accessToken;
        }
      }

      if (tokenName) {
        let session = yield _this90.session.getAuthData();

        if (!session) {
          session = yield _this90.authConfig.generateChallengeAndVerifier();
        }

        let refreshToken = '';

        if (_this90.storage.getRefreshToken) {
          refreshToken = yield _this90.storage.getRefreshToken();
        }

        const result = yield _this90.internalGetToken('refresh_token', refreshToken, 'refresh_token', session.verifier, scopes);

        if (result) {
          yield _this90.setSession(result, tokenName, scopes);

          _this90.logger.debug(_this90.logTag, 'Acquired a new token.', tokenName, scopes);

          return result.accessToken;
        }

        _this90.logger.debug(_this90.logTag, 'Could not acquire a new token for: ', tokenName, scopes);

        throw 'No token could be acquired.';
      } else {
        if (_this90.storage.getAuthResponse) {
          const authResponse = yield _this90.storage.getAuthResponse();

          if (authResponse && authResponse.accessToken) {
            _this90.logger.debug(_this90.logTag, 'returning authResponse accessToken');

            return authResponse.accessToken;
          }
        }

        if (_this90.authResult && _this90.authResult.accessToken) {
          _this90.logger.debug(_this90.logTag, 'returning authResult accessToken');

          return _this90.authResult.accessToken;
        }
      }

      _this90.logger.debug(_this90.logTag, 'Could not find a token, failing.');

      throw 'Authenticated, but token not found.';
    })();
  }

  expire(tokenName) {
    var _this91 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this91.session.setExpiresAt(0, tokenName);
    })();
  }

  logout() {
    var _this92 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this92.getOverrideDiscoveryUrl();
      const url = yield _this92.authConfig.getLogoutUrl();
      logging.debug('logout url: ' + url.url);
      yield _this92.showUrl(url.url, {
        hide: true
      }, _this92.options.logoutUrl);
      yield _this92.finishLogout();
    })();
  }

  finishLogout() {
    var _this93 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this93.authResult = undefined;
      yield _this93.clearStorage();
      _this93.authConfig.locations = undefined;
      yield _this93.clearOverrideDiscoveryUrl();

      _this93.onLogout();
    })();
  }

  onLoginSuccess(authResponse) {
    this.authConfig.locations = undefined;
    this.authConfig.overrideDiscoveryUrl = '';
    this.handlers.onLoginSuccess(authResponse);
  }

  onLogout() {
    this.handlers.onLogout();
  }

  clearStorage() {
    var _this94 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this94.session.clear();

      if (_this94.storage.clear) {
        yield _this94.storage.clear();
      }
    })();
  }

}

class IonicAuthWeb extends IonicBaseAuth {
  constructor(options, handlers) {
    super(options, handlers);
    this.options = options;
    this.handlers = handlers;
    this.logTag = 'IonicWebAuth: ';
    this.logger.debug(this.logTag, 'ctor options', options);
    window.addEventListener('message', event => {
      this.logger.debug(this.logTag, 'event: ', event);
    });
  }

  internalGetToken(_codeName, _code, _grantType, _verifier, scope) {
    var _this95 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this95.logger.debug(_this95.logTag, 'getting token'); // setup the env for a new token request


      const keys = yield _this95.authConfig.generateChallengeAndVerifier();
      yield _this95.session.setAuthData(keys);
      const nonce = (yield _this95.session.getNonce()) || ''; // setup the url for the token

      let urlInfo = yield _this95.authConfig.getAuthorizeUrl(nonce, keys.challenge, {});
      let url = new URL(urlInfo.url);
      url.searchParams.set('prompt', 'none');
      url.searchParams.set('scope', scope);
      url.searchParams.set('response_type', 'token');

      _this95.logger.debug(_this95.logTag, 'url for internalGetToken: ', url.href);

      const result = yield _this95.hiddenLoadUrl(url.href);
      const callbackString = result.callback;

      if (callbackString != undefined && callbackString != '') {
        const parsedUrl = urlParse(callbackString, true);
        let result = UrlHelper.parseHash(parsedUrl.hash);
        const authResult = {
          accessToken: result.access_token,
          idToken: result.id_token,
          refreshToken: result.refresh_token,
          expiresIn: result.expires_in,
          scope: result.scope,
          tokenType: result.token_type
        };

        _this95.logger.debug(_this95.logTag, 'returning authResult: ', authResult);

        return authResult;
      } else {
        var error = 'could not get token';

        _this95.logger.error(error);

        throw error;
      }
    })();
  }

  internalHandleCallback(url, externalCallback) {
    var _this96 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this96.logger.debug(_this96.logTag, 'handleCallback url:' + url);

      const parsedUrl = urlParse(url, true);
      const searchParams = new URLSearchParams(parsedUrl.hash);

      _this96.logger.debug(_this96.logTag, 'searchParams: ', JSON.stringify(searchParams));

      if (searchParams.has('error_description')) {
        const errorDescription = searchParams.get('error_description');

        _this96.logger.debug('error_description' + errorDescription);

        throw new Error(errorDescription);
      }

      const query_params = parsedUrl.query;

      _this96.logger.debug(_this96.logTag, 'query params: ', query_params);

      const hash = UrlHelper.parseHash(parsedUrl.hash);

      _this96.logger.debug(_this96.logTag, 'hash: ', hash);

      if (hash.access_token != undefined && hash.id_token != undefined || _this96.options.webAuthFlow && _this96.options.webAuthFlow === 'PKCE' && query_params.code != undefined) {
        let result = {};
        const session = yield _this96.session.getAuthData();

        if (!session) {
          throw new Error('No session data stored');
        }

        _this96.logger.debug(_this96.logTag, 'got a session');

        if (query_params.code != undefined) {
          var options = {
            grant_type: 'authorization_code',
            client_id: _this96.options.clientID,
            code_verifier: session.verifier,
            code: query_params.code,
            redirect_uri: String(_this96.options.redirectUri)
          };
          result = yield _this96.postToken(options);
        } else {
          result = hash;
        }

        return yield _this96.handleAuthResult(result);
      } else {
        var error = 'Web only supports implicit login with id and access token returned from the authorize call or PKCE';

        _this96.logger.error(error);

        throw error;
      }
    })();
  }

  refreshSession(tokenName) {
    var _this97 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this97.logger.debug(_this97.logTag, 'refreshing session');

      yield _this97.getOverrideDiscoveryUrl();

      if (tokenName) {
        _this97.logger.debug(_this97.logTag, 'refreshing other token: ', tokenName);

        const scope = yield _this97.session.getTokenScopes(tokenName);
        const authResult = yield _this97.internalGetToken('', '', '', undefined, scope);
        yield _this97.setSession(authResult, tokenName, scope);
        return;
      }

      if (_this97.options.webAuthFlow === 'PKCE') {
        const refreshToken = yield _this97.getRefreshToken();

        if (!refreshToken) {
          throw new Error('No refresh token available');
        }

        let options = {
          grant_type: 'refresh_token',
          client_id: _this97.options.clientID,
          refresh_token: refreshToken
        };
        const result = yield _this97.postToken(options);
        yield _this97.handleAuthResult(result);
      } else {
        const keys = yield _this97.authConfig.generateChallengeAndVerifier();
        yield _this97.session.clearAuthData();
        yield _this97.session.setAuthData(keys);

        _this97.logger.debug(_this97.logTag, 'keys: ', keys);

        const nonce = (yield _this97.session.getNonce()) || '';

        _this97.logger.debug(_this97.logTag, 'nonce: ', nonce);

        let url = yield _this97.authConfig.getAuthorizeUrl(nonce, keys.challenge, {});
        url.url = url.url + '&prompt=none';

        _this97.logger.debug(_this97.logTag, 'url for refresh: ', url.url);

        try {
          const result = yield _this97.hiddenLoadUrl(url.url);

          _this97.logger.debug(_this97.logTag, 'result for refresh: ', result);

          const callbackString = result.callback;

          if (callbackString != undefined && callbackString != '') {
            _this97.logger.debug(_this97.logTag, 'calling handleCallback');

            yield _this97.internalHandleCallback(callbackString, false);
          }
        } catch (e) {
          var error = 'Failed to refresh session';

          _this97.logger.error(error);

          throw error;
        }
      }
    })();
  }

  handleAuthResult(result) {
    var _this98 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this98.storage.setAuthResponse) {
        yield _this98.storage.setAuthResponse(result);
      }

      _this98.logger.debug(_this98.logTag, 'result: ', result);

      const authResult = {
        accessToken: result.access_token,
        idToken: result.id_token,
        refreshToken: result.refresh_token,
        expiresIn: result.expires_in,
        scope: result.scope,
        tokenType: result.token_type
      };
      yield _this98.setSession(authResult);

      _this98.logger.debug(_this98.logTag, 'clear auth data');

      yield _this98.session.clearAuthData();

      _this98.logger.debug(_this98.logTag, 'return auth result', authResult);

      return authResult;
    })();
  }

  postToken(options) {
    var _this99 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tokenUrlInfo = yield _this99.authConfig.getTokenUrl();
      const tokenUrl = tokenUrlInfo.url || '';
      const headers = Object.assign(Object.assign({}, tokenUrlInfo.headers), {
        'Content-Type': 'application/x-www-form-urlencoded'
      });
      options = Object.assign(Object.assign({}, tokenUrlInfo.payload), options);
      const bodyParams = Object.keys(options).map(key => {
        return encodeURIComponent(key) + '=' + encodeURIComponent(options[key]);
      }).join('&');
      const response = yield fetch(tokenUrl, {
        method: 'POST',
        headers: headers,
        body: bodyParams
      });

      if (!response.ok) {
        const jsonRes = yield response.json();
        const errorMessage = `POST to token endpoint failed with error: ${jsonRes.error_description ? jsonRes.error_description : jsonRes.error}`;

        _this99.logger.error(errorMessage);

        throw errorMessage;
      }

      return JSON.parse(yield response.text());
    })();
  }

  hiddenLoadUrl(url) {
    try {
      return new Promise((resolve, reject) => {
        this.logger.debug(this.logTag, 'opening browser.');
        let iframeLocation;
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = url;
        document.getElementsByTagName('body')[0].appendChild(iframe);
        iframe.src = url;
        const that = this;
        var timer = window.setInterval(() => {
          try {
            if (iframe === null) {
              return;
            }

            if (iframe.contentWindow !== null) {
              iframeLocation = iframe.contentWindow.location;
            } else if (iframe.contentDocument !== null) {
              iframeLocation = iframe.contentDocument.location;
            } else {
              this.logger.debug(this.logTag, 'no doc or window');
              return;
            }

            if (!encodeURI(iframeLocation.href).indexOf(encodeURI(that.options.redirectUri))) {
              window.clearInterval(timer);
              const href = iframeLocation.href;
              this.logger.debug(this.logTag, 'closing iframe: ', href);

              if (iframe.parentNode !== null) {
                iframe.parentNode.removeChild(iframe);
              }

              this.logger.debug(this.logTag, 'calling resolve');
              resolve({
                event: 'opened',
                callback: href
              });
            }

            return;
          } catch (e) {
            window.clearInterval(timer);
            this.logger.error(this.logTag, e.message);
            reject(e.message);
          }
        }, 1);
      });
    } catch (err) {
      this.logger.error(this.logTag, 'hiddenLoadUrl error: ', err);
      throw err;
    }
  }

  showUrl(url, _options, urlToCloseWindow = this.options.redirectUri) {
    try {
      if (this.options.implicitLogin !== 'CURRENT') {
        // POPUP
        return new Promise((resolve, reject) => {
          this.logger.debug(this.logTag, 'opening browser.');
          let popupLocation;
          const popup = window.open(url, '_system');
          var timer = window.setInterval(() => {
            if (!popup || popup.closed) {
              window.clearInterval(timer);
              const error = 'popup window closed without navigating to result url';
              this.logger.error(this.logTag, error);
              reject(error);
            }

            try {
              if (!popup) {
                return;
              }

              popupLocation = popup.location;

              if (!encodeURI(popupLocation.href).indexOf(encodeURI(urlToCloseWindow))) {
                window.clearInterval(timer);
                const popupString = popupLocation.toString();
                this.logger.debug(this.logTag, 'closing popup: ', popupLocation);
                popup.close();
                this.logger.debug(this.logTag, 'closed popup', popupString);
                resolve({
                  event: 'opened',
                  callback: popupString
                });
              }

              return;
            } catch (e) {// While the URL is at the auth provider, we will get a DOMException error trying to access the window.
              // We eat the error and try again.
            }
          }, 1);
        });
      } else {
        // CURRENT
        logging.debug(this.logTag, 'about to navigate forward');
        window.location.replace(url);
        return new Promise(() => {});
      }
    } catch (err) {
      this.logger.error(this.logTag, 'showUrl error: ', err);
      throw err;
    }
  }

}

class SecureWebView {
  isAvailable(callback) {
    var errorHandler = function errorHandler(error) {
      // An error has occurred while trying to access the
      // SecureWebView native implementation, most likely because
      // we are on an unsupported platform.
      callback(false);
    };

    cordova.exec(callback, errorHandler, 'SecureWebView', 'isAvailable', []);
  } // options:
  //  url - url to display
  //  webView - for iOS which webview to display, if possible. By default we use the newest one available for OS version
  //      - ASWebAuth - ASWebAuthenticationSession (avaialble starting in iOS 12)
  //      - SFAuth - SFAuthenticationSession (available starting in iOS 11)
  //      - SFSafari - SFSafariViewController (available starting in iOS 9)
  //      - MobileSafari - Mobile Safari (pre-iOS 8)


  show(options, onSuccess, onError) {
    options = options || {};

    if (!options.hasOwnProperty('animated')) {
      options.animated = true;
    }

    cordova.exec(onSuccess, onError, 'SecureWebView', 'show', [options]);
  }

  hide(onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'hide', []);
  }

  getViewHandlerPackages(onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'getViewHandlerPackages', []);
  }

  useCustomTabsImplementation(packageName, onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'useCustomTabsImplementation', [packageName]);
  }

  connectToService(onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'connectToService', []);
  }

  warmUp(onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'warmUp', []);
  }

  mayLaunchUrl(url, onSuccess, onError) {
    cordova.exec(onSuccess, onError, 'SecureWebView', 'mayLaunchUrl', [url]);
  }

}

const IonicSecureWebView = new SecureWebView();
const ready = new Promise(resolve => {
  const DEVICE_READY_TIMEOUT = 5000;
  const readyTimeout = setTimeout(() => {
    console.warn(`Auth Connect: deviceready did not fire within ${DEVICE_READY_TIMEOUT}ms.`);
    resolve();
  }, DEVICE_READY_TIMEOUT);
  document.addEventListener('deviceready', () => {
    clearTimeout(readyTimeout);
    resolve();
  });
});

class IonicNativeAuth extends IonicBaseAuth {
  constructor() {
    super(...arguments);
    this.logTag = 'IonicNativeAuth: ';
  }

  internalGetToken(codeName, code, grantType, verifier, scope) {
    var _this100 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let payload;
      payload = {
        grant_type: grantType,
        client_id: _this100.options.clientID,
        code_verifier: verifier,
        redirect_uri: String(_this100.options.redirectUri)
      };
      payload[codeName] = String(code);
      const tokenUrlInfo = yield _this100.authConfig.getTokenUrl();
      const tokenUrl = tokenUrlInfo.url || '';

      if (tokenUrlInfo.payload) {
        payload = Object.assign(Object.assign({}, tokenUrlInfo.payload), payload);
      }

      if (scope != undefined) {
        payload.scope = scope;
      }

      let headers = {};

      if (tokenUrlInfo.headers) {
        headers = tokenUrlInfo.headers;
      } else {
        headers = {
          'Content-Type': 'application/json'
        };
      } // need to await device ready


      return yield UrlHelper.post(tokenUrl, payload, headers).then( /*#__PURE__*/function () {
        var _ref9 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (response) {
          const result = JSON.parse(response.data);

          if (_this100.storage.setAuthResponse && grantType != 'refresh_token') {
            yield _this100.storage.setAuthResponse(result);
          }

          _this100.logger.debug(_this100.logTag, 'got result', result);

          _this100.logger.debug(_this100.logTag, 'access_token', result.access_token);

          _this100.logger.debug(_this100.logTag, 'id_token', result.id_token);

          _this100.logger.debug(_this100.logTag, 'refresh_token', result.refresh_token);

          _this100.logger.debug(_this100.logTag, 'profile_info', result.profile_info);

          _this100.logger.debug(_this100.logTag, 'expires_in', result.expires_in);

          const authResult = {
            accessToken: result.access_token,
            idToken: result.id_token,
            refreshToken: result.refresh_token,
            expiresIn: result.expires_in,
            scope: result.scope,
            tokenType: result.token_type
          };
          return authResult;
        });

        return function (_x7) {
          return _ref9.apply(this, arguments);
        };
      }()).catch(error => {
        _this100.logger.debug(tokenUrl, _this100.logTag, ' - tokenUrl');

        _this100.logger.debug(headers, _this100.logTag, ' - headers');

        _this100.logger.debug(payload, _this100.logTag, ' - payload');

        _this100.logger.error(_this100.logTag, error);

        return {};
      });
    })();
  }

  internalHandleCallback(url, _externalCallback) {
    var _this101 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const session = yield _this101.session.getAuthData();

      if (!session) {
        throw new Error('No session data stored');
      }

      let {
        code
      } = urlParse(url, true).query;
      yield ready;
      let grantType = 'authorization_code';
      let codeName = 'code';

      try {
        const result = yield _this101.internalGetToken(codeName, code, grantType, session.verifier, undefined);
        yield _this101.setSession(result);
        yield _this101.session.clearAuthData();
        IonicSecureWebView.hide(data => {
          _this101.logger.debug(_this101.logTag, 'IonicSecureWebView.hide succeeded: ', data);
        }, err => {
          _this101.logger.error(_this101.logTag, 'IonicSecureWebView.hide failed: ', err);
        });
        return result;
      } catch (err) {
        yield _this101.session.clearAuthData();

        _this101.logout();

        throw err;
      }
    })();
  }

  refreshSession(tokenName) {
    var _this102 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this102.getOverrideDiscoveryUrl();

      _this102.logger.debug(_this102.logTag, 'refresh flow');

      const url = yield _this102.authConfig.getTokenUrl();
      const nonce = yield _this102.session.getNonce();
      const refreshToken = yield _this102.getRefreshToken();

      if (!refreshToken) {
        throw new Error('No refresh token available');
      }

      let payload;
      payload = {
        client_id: _this102.options.clientID,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
        nonce,
        state: nonce
      };

      if (url.payload) {
        payload = Object.assign(Object.assign({}, url.payload), payload);
      }

      let secondaryToken = false;

      if (tokenName) {
        payload.scope = yield _this102.session.getTokenScopes(tokenName);
        secondaryToken = true;
      }

      const headers = url.headers ? url.headers : {
        'Content-Type': 'application/json'
      };
      yield ready;
      return yield UrlHelper.post(url.url || '', payload, headers).then( /*#__PURE__*/function () {
        var _ref10 = (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (response) {
          const result = JSON.parse(response.data);

          if (_this102.storage.setAuthResponse && !secondaryToken) {
            yield _this102.storage.setAuthResponse(result);
          }

          const authResult = {
            accessToken: result.access_token,
            idToken: result.id_token,
            refreshToken: result.refresh_token,
            expiresIn: result.expires_in,
            scope: result.scope,
            tokenType: result.token_type
          };
          yield _this102.setSession(authResult, tokenName, result.scope);
          return;
        });

        return function (_x8) {
          return _ref10.apply(this, arguments);
        };
      }()).catch(error => {
        _this102.logger.debug(_this102.logTag, 'tokenUrl: ' + url.url);

        _this102.logger.debug(_this102.logTag, 'headers: ', headers);

        _this102.logger.debug(_this102.logTag, 'payload: ', payload);

        _this102.logger.error(_this102.logTag, error);

        throw error;
      });
    })();
  }

  showUrl(url, options) {
    return new Promise((resolve, reject) => {
      let curOptions = {};

      if (this.options.androidToolbarColor) {
        curOptions = Object.assign(Object.assign({}, curOptions), {
          toolbarColor: this.options.androidToolbarColor
        });
      }

      if (this.options.safariWebViewOptions) {
        curOptions = Object.assign(Object.assign({}, curOptions), this.options.safariWebViewOptions);
      }

      this.logger.debug(this.logTag, 'webView option: ', this.authConfig.options.iosWebView);
      const params = Object.assign({}, {
        url,
        callbackUrl: this.authConfig.options.redirectUri,
        iosWebView: this.authConfig.options.iosWebView
      }, curOptions);
      this.logger.debug(this.logTag, 'using params: ', params);
      IonicSecureWebView.show(params, result => {
        this.logger.debug(this.logTag, 'result :', result);
        resolve(result);
      }, error => {
        this.logger.error(this.logTag, 'show failed: ', error);
        reject(error);
      });
    });
  }

}

class IonicAuth {
  constructor(options) {
    this.implementation = this.getImplementation(options);
  }
  /**
   * Using configuration display the auth provider's login UI.
   *
   *  The overrideUrl parameter should only be used when the default
   *  discovery url needs to be overrode. (The known use case is with Azure AD
   *  custom user flows/policies.)
   *
   * @example
   * myAuthService.login("")
   */


  login(overrideUrl) {
    return this.implementation.login(overrideUrl);
  }
  /**
   * Add additional parameters to the login request.
   *
   * @example
   * myAuthService.additionalLoginParameters({ 'login_hint': 'neighbors cat name' })
   *
   * @param parameters any additional parameters that should be added to the login request
   *  examples: `login_hint`, `domain_hint`
   */


  additionalLoginParameters(parameters) {
    return this.implementation.additionalLoginParameters(parameters);
  }
  /**
   * Get the access token, once logged in, for API calls.
   *
   * @example
   * myAuthService.getAccessToken()
   *
   * @param tokenName Optional token name, only used when multiple tokens are required (Azure specific feature).
   * @param scopes The scopes for the access token.
   */


  getAccessToken(tokenName, scopes) {
    return this.implementation.getAccessToken(tokenName, scopes);
  }
  /**
   * Get the unparsed id token.
   *
   * @example
   * myAuthService.getRawIdToken()
   */


  getRawIdToken() {
    return this.implementation.getRawIdToken();
  }
  /**
   * Get the parsed id token, includes requested scope values.
   *
   * @example
   * myAuthService.getIdToken()
   */


  getIdToken() {
    return this.implementation.getIdToken();
  }
  /**
   * Get the full original auth response.
   *
   * @example
   * myAuthService.getAuthResponse()
   */


  getAuthResponse() {
    return this.implementation.getAuthResponse();
  }
  /**
   * Check to see if the access token is available.
   *
   * @example
   * myAuthService.isAccessTokenAvailable()
   *
   * @param tokenName Optional token name, only used when multiple tokens are required (Azure specific feature).
   */


  isAccessTokenAvailable(tokenName) {
    return this.implementation.isAccessTokenAvailable(tokenName);
  }
  /**
   * Check to see if the access token is expired.
   *
   * @example
   * myAuthService.isAccessTokenExpired()
   */


  isAccessTokenExpired() {
    return this.implementation.isAccessTokenExpired();
  }
  /**
   * Check to see if the refresh token is available.
   *
   * @example
   * myAuthService.isRefreshTokenAvailable()
   */


  isRefreshTokenAvailable() {
    return this.implementation.isRefreshTokenAvailable();
  }
  /**
   * Get the refresh token if available.
   *
   * @example
   * myAuthService.getRefreshToken()
   */


  getRefreshToken() {
    return this.implementation.getRefreshToken();
  }
  /**
   * Refresh the session, throws if refresh token is invalid or missing.
   *
   * @example
   * myAuthService.refreshSession()
   *
   * @param tokenName Optional token name, only used when multiple tokens are required (Azure specific feature).
   */


  refreshSession() {
    return this.implementation.refreshSession();
  }
  /**
   * Check to see if the user is logged in, and refresh the token if needed.
   *
   * @example
   * const isAuth = myAuthService.isAuthenticated()
   */


  isAuthenticated() {
    return this.implementation.isAuthenticated();
  }
  /**
   * Log the user out and clear all tokens & data stored in the {@link TokenStorageProvider} as well as any
   * metadata relevant to the existing session such as access token expiration time.
   *
   * @example
   * myAuthService.logout()
   */


  logout() {
    return this.implementation.logout();
  }
  /**
   * Expire the current access token, but keep the refresh token, useful for testing.
   *
   * @example
   * myAuthService.expire()
   */


  expire() {
    return this.implementation.expire();
  }
  /**
   * Called by the hosting app when login callbacks happen, these will be to the URL specified
   *  in the options for RedirectUri.
   *
   * @example
   * myAuthService.handleLoginCallback()
   *
   * @param url callback url to handle @default defaults to `window.location.href`
   */


  handleLoginCallback(url) {
    return this.implementation.handleLoginCallback(url);
  }
  /**
   * Called by the hosting app when logout callbacks happens.
   *
   * @example
   * myAuthService.handleLogoutCallback()
   */


  handleLogoutCallback() {
    return this.implementation.handleLogoutCallback();
  }
  /**
   * Called by the hosting app when callbacks happen, these will be to the URL specified
   *  in the options for LogoutUrl and RedirectUri.
   *
   * @example
   * myAuthService.handleCallback(window.location.href)
   *
   * @deprecated Use [handleLoginCallback](#iionicauth.handlelogincallback) instead
   * @param url callback url to handle
   */


  handleCallback(url) {
    return this.implementation.handleLoginCallback(url);
  }
  /**
   * This method will clear all tokens & data stored in the {@link TokenStorageProvider} as well as any
   * metadata relevant to the existing session such as access token expiration time.
   *
   * @example
   * myAuthService.clearStorage()
   */


  clearStorage() {
    var _this103 = this;

    return (0,_Users_damian_Sample_Code_iv_test_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this103.implementation.clearStorage();
    })();
  }
  /**
   * Override the discovery url used for login in a way that persists.
   *
   * @example
   * myAuthService.setOverrideDiscoveryUrl("https://myurl")
   *
   * @param url the discovery url used for login
   */


  setOverrideDiscoveryUrl(url) {
    return this.implementation.setOverrideDiscoveryUrl(url);
  }
  /**
   * Clear previosly persisted override of the discovery url used for login.
   *
   * @example
   * myAuthService.clearOverrideDiscoveryUrl()
   */


  clearOverrideDiscoveryUrl() {
    return this.implementation.clearOverrideDiscoveryUrl();
  }
  /**
   * Clear previosly persisted override of the discovery url used for login.
   *
   * @example
   * myAuthService.getOverrideDiscoveryUrl()
   */


  getOverrideDiscoveryUrl() {
    return this.implementation.getOverrideDiscoveryUrl();
  }
  /**
   * Get the time the access token will expire in milliseconds from the epoch.
   *
   * @example
   * myAuthService.getAccessTokenExpiration()
   */


  getAccessTokenExpiration() {
    return this.implementation.getAccessTokenExpiration();
  }
  /**
   * Event handler which can be overridden to handle successful login events.
   *
   * @usage
   * ```typescript
   * async onLoginSuccess(): Promise<void> {
   *  // do something here
   * }
   * ```
   * @param result the auth result from a successful login
   */


  onLoginSuccess(result) {}
  /**
   * Event handler which can be overridden to handle successful logout events.
   *
   * @usage
   * ```typescript
   * async onLogout(): Promise<void> {
   *  // do something here
   * }
   * ```
   */


  onLogout() {}

  getImplementation(options) {
    switch (options.platform) {
      case 'web':
        return new IonicAuthWeb(options, {
          onLoginSuccess: this.onLoginSuccess.bind(this),
          onLogout: this.onLogout.bind(this)
        });

      default:
        return new IonicNativeAuth(options, {
          onLoginSuccess: this.onLoginSuccess.bind(this),
          onLogout: this.onLogout.bind(this)
        });
    }
  }

}



/***/ })

}]);
//# sourceMappingURL=src_app_tab1_tab1_module_ts.js.map