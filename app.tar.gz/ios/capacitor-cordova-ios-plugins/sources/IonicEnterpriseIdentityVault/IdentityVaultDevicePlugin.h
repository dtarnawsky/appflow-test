//
//  IdentityVaultDevicePlugin.h
//  IdentityVaultDevicePlugin
//

#import <UIKit/UIKit.h>

//! Project version number for IdentityVaultDevicePlugin.
FOUNDATION_EXPORT double IdentityVaultDevicePluginVersionNumber;

//! Project version string for IdentityVaultDevicePlugin.
FOUNDATION_EXPORT const unsigned char IdentityVaultDevicePluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdentityVaultDevicePlugin/PublicHeader.h>


