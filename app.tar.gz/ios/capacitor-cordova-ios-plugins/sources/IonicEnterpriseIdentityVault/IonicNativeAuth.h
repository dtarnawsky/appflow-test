//
//  IonicNativeAuth.h
//  IonicNativeAuth
//
//  Created by Max Lynch on 4/10/18.
//  Copyright © 2018 Max Lynch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IonicNativeAuth.
FOUNDATION_EXPORT double IonicNativeAuthVersionNumber;

//! Project version string for IonicNativeAuth.
FOUNDATION_EXPORT const unsigned char IonicNativeAuthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IonicNativeAuth/PublicHeader.h>


