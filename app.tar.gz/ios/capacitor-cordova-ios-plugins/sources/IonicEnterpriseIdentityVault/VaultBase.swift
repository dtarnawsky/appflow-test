import Cordova
import Foundation
import LocalAuthentication

// swiftlint:disable type_body_length
class VaultBase {

    internal var data: [String: String]?
    internal var accessControl: SecAccessControl?
    internal var authContext: LAContext?

    internal var customPasscode: String?
    internal var config: IdentityVaultConfig
    private var backgroundEnteredTime: Date?
    internal var allowedInvalidUnlockAttempts: Int32 = 0

    internal var onLockCallback: ((Bool) throws -> Void)?
    internal var onUnlockCallback: (() -> Void)?
    internal var onErrorCallback: ((Error, String) -> Void)?
    internal var errorCallbackId: String?

    internal var vaultType: String? {
        return nil
    }

    init(_ config: IdentityVaultConfig) throws {
        self.config = config
    }

    func clear() throws {
        try clearData()
        try clearVaultType()
        try clearVaultDeviceSecurityType()
        try clearAuthPolicyDomainState()
        clearIsEmptyFlag()
        self.data = nil
        self.customPasscode = nil
    }

    @available(*, deprecated, message: "Deprecated in favor of using the isEmpty method.")
    func doesVaultExist() throws -> Bool {
        return try self.checkIfVaultExists()
    }

    func exportVault() throws -> [String: String]? {
        try unlock()
        return self.data
    }

    func lock(_ wasTimeout: Bool) throws {
        if !self.isLocked() {
            if try self.doesVaultExist() {
                self.data = nil
                self.customPasscode = nil
                if self.onLockCallback != nil {
                    try self.onLockCallback!(wasTimeout)
                }
            }
        }
    }

    func getKeys() throws -> [String] {
        if try !self.doesVaultExist() {
            return []
        }
        try unlock()
        return Array(self.data!.keys)
    }

    func isEmpty() -> Bool {
        return getIsEmptyFlag()
    }

    func isLocked() -> Bool {
        return self.data == nil
    }

    func isVaultInvalidated() throws -> Bool {
        // 1. if biometric vault, get previously stored auth policy state
        // 2. get current auth policy state
        // 3. if different, biometrics have been invalidated
        if self.vaultType == VaultType.DEVICE_SECURITY.rawValue {
            guard let currentPolicyState = getCurrentAuthPolicyDomainState() else {
                // if current policy state is nil, biometrics is not available
                return true
            }

            let storedPolicyState = try VaultBase.getPersistedAuthPolicyDomainState(key: self.config.key)

            return currentPolicyState != storedPolicyState
        }

        return false
    }

    func importVault(_ data: [String: String]) throws {
        try unlock()
        self.data = data
        try storeData()
    }

    func getValue(_ key: String) throws -> String? {
        if try !self.doesVaultExist() {
            return nil
        }
        try unlock()
        let value = self.data?[key]
        return value
    }

    func setCustomPasscode(_ passcode: String) throws {
        let isCustomPasscodeVault = self.vaultType == VaultType.CUSTOM_PASSCODE.rawValue
        if isCustomPasscodeVault && self.customPasscode != nil && self.customPasscode != passcode {
            let data = try self.exportVault()
            self.customPasscode = passcode
            self.authContext!.setCredential(self.customPasscode!.data(using: .utf8), type: .applicationPassword)
            try self.importVault(data!)
        } else {
            self.customPasscode = passcode
        }
    }

    func setValue(_ key: String, _ value: String?) throws {
        try unlock()
        self.data![key] = value
        try storeData()
    }

    func onLock(_ callback: @escaping (Bool) throws -> Void) {
        self.onLockCallback = callback
    }

    func onUnlock(_ callback: @escaping () -> Void) {
        self.onUnlockCallback = callback
    }

    func onError(_ callbackId: String, _ callback: @escaping(Error, String) -> Void) {
        self.errorCallbackId = callbackId
        self.onErrorCallback = callback
    }

    public static func getPersistedAuthPolicyDomainState(key: String) throws -> Data? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(key)_policyDomainState".data(using: .utf8)!,
            kSecMatchLimit: 1,
            kSecReturnAttributes: true,
            kSecReturnData: true
        ] as Dictionary

        var queryResult: AnyObject?

        let status = SecItemCopyMatching(query as CFDictionary, &queryResult)
        guard status != errSecItemNotFound else {
            return nil
        }
        guard status == noErr else { throw VaultError.unhandledError(status.description) }

        // swiftlint:disable:next force_cast
        let rawData = queryResult!.value(forKey: kSecValueData as String) as! Data

        return rawData
    }

    public static func getPersistedVaultType(key: String) throws -> String? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(key)_vaultType".data(using: .utf8)!,
            kSecMatchLimit: 1,
            kSecReturnAttributes: true,
            kSecReturnData: true
        ] as Dictionary

        var queryResult: AnyObject?

        let status = SecItemCopyMatching(query as CFDictionary, &queryResult)
        guard status != errSecItemNotFound else {
            return nil
        }
        guard status == noErr else { throw VaultError.unhandledError(status.description) }

        // swiftlint:disable:next force_cast
        let rawData = queryResult!.value(forKey: kSecValueData as String) as! Data
        return String(data: rawData, encoding: .utf8)
    }

    public static func getPersistedVaultDeviceSecurityType(key: String) throws -> String? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(key)_vaultDeviceSecurityType".data(using: .utf8)!,
            kSecMatchLimit: 1,
            kSecReturnAttributes: true,
            kSecReturnData: true
        ] as Dictionary

        var queryResult: AnyObject?

        let status = SecItemCopyMatching(query as CFDictionary, &queryResult)
        guard status != errSecItemNotFound else {
            return nil
        }
        guard status == noErr else { throw VaultError.unhandledError(status.description) }

        // swiftlint:disable:next force_cast
        let rawData = queryResult!.value(forKey: kSecValueData as String) as! Data
        return String(data: rawData, encoding: .utf8)
    }

    public func removeValue(_ key: String) throws {
        try unlock()
        self.data!.removeValue(forKey: key)
        try storeData()
    }

    func unlock(_ forceUnlock: Bool = true) throws {
        if self.isLocked() {
            if try self.doesVaultExist() || forceUnlock {
                try getData()
                if self.onUnlockCallback != nil {
                    self.onUnlockCallback!()
                }
            }
        }
    }

    internal func appLaunched() throws {
        if self.config.unlockVaultOnLoad == true {
            try self.unlock(false)
        }
    }

    internal func appResumed() throws {
        if self.config.lockAfterBackgrounded != nil && self.backgroundEnteredTime != nil {
            let elapsed = Date().timeIntervalSince(self.backgroundEnteredTime!) * 1000

            if !elapsed.isLessThanOrEqualTo(Double(self.config.lockAfterBackgrounded!)) {
                try self.lock(true)
            }
        }
        self.backgroundEnteredTime = nil
        if self.isLocked() && self.config.unlockVaultOnLoad == true {
            try self.unlock(false)
        }
    }

    internal func backgroundEntered() {
        if self.config.lockAfterBackgrounded != nil {
            self.backgroundEnteredTime = Date()
        }
    }

    private func checkIfVaultExists() throws -> Bool {
        if !self.isLocked() {
            return true
        }
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: self.config.key.data(using: .utf8)!,
            kSecUseAuthenticationUI as AnyHashable: kSecUseAuthenticationUIFail
        ] as Dictionary

        let status = SecItemCopyMatching(query as CFDictionary, nil)

        switch status {
        case errSecItemNotFound:
            if !isEmpty() {
                if try self.isVaultInvalidated() {
                    try self.clear()
                    throw VaultError.invalidatedCredentials
                }
            }

            return false
        case noErr:
            return true
        case errSecInteractionNotAllowed:
            // If errSecInteractionNotAllowed, the key is present, but we aren't allowed to access it without auth
            return true
        case errSecAuthFailed:
            if !Device().isBiometricsSupported {
                throw VaultError.biometricsNotEnabled
            }

            if Device().isLockedOut {
                throw VaultError.biometricsLockedOut
            }

            throw VaultError.authFailed
        default:
            throw VaultError.unhandledError(status.description)
        }
    }

    internal func getData() throws {
        if self.data == nil {
            defer {
                if Device.isShowingBiometrics {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        Device.isShowingBiometrics = false
                    }
                }
            }

            if !isEmpty() {
                if try self.isVaultInvalidated() {
                    try self.clear()
                    throw VaultError.invalidatedCredentials
                }
            }

            var query = [
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: self.config.key.data(using: .utf8)!,
                kSecMatchLimit: 1,
                kSecReturnAttributes: true,
                kSecReturnData: true
            ] as Dictionary

            if self.accessControl != nil {
                query[kSecAttrAccessControl] = self.accessControl as Any
            }

            if self.authContext != nil {
                query[kSecUseAuthenticationContext] = self.authContext
            }

            var queryResult: AnyObject?

            if self.customPasscode == nil {
                Device.isShowingBiometrics = true
            }

            let status = SecItemCopyMatching(query as CFDictionary, &queryResult)

            switch status {
            case errSecItemNotFound:
                self.data = [:]
                try self.storeData()
                return
            case errSecAuthFailed:
                self.data = nil
                self.customPasscode = nil

                if !Device().isBiometricsSupported {
                    throw VaultError.biometricsNotEnabled
                }

                if Device().isLockedOut {
                    throw VaultError.biometricsLockedOut
                }

                if self.vaultType == VaultType.CUSTOM_PASSCODE.rawValue {
                    var failedUnlockAttempts = try self.getFailedUnlockAttempts()
                    failedUnlockAttempts += 1

                    if self.config.shouldClearVaultAfterTooManyFailedAttempts ?? false {
                        if failedUnlockAttempts >= self.allowedInvalidUnlockAttempts {
                            try self.clear()
                            try self.setFailedUnlockAttempts(attempts: 0)

                            throw VaultError.tooManyFailedAttempts
                        }
                    }

                    try self.setFailedUnlockAttempts(attempts: failedUnlockAttempts)
                }

                Device.setBiometricPermissionPromptState(prompted: true)
                throw VaultError.authFailed
            case errSecUserCanceled:
                throw VaultError.userCanceledAuth
            case noErr:
                Device.setBiometricPermissionPromptState(prompted: true)
                try self.setFailedUnlockAttempts(attempts: 0)
                // swiftlint:disable:next force_cast
                let rawData = queryResult!.value(forKey: kSecValueData as String) as! Data

                self.data = try JSONSerialization.jsonObject(with: rawData, options: []) as? [String: String] ?? [:]
                refreshIsEmptyFlag()
            default:
                print("unknown error: \(status.description)")
                throw VaultError.unhandledError(status.description)

            }

        }
    }

    private func getCurrentAuthPolicyDomainState() -> Data? {
        if self.vaultType == VaultType.DEVICE_SECURITY.rawValue {
            let authContext = LAContext()
            if authContext.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
                guard let stateData = authContext.evaluatedPolicyDomainState else {
                    return Data.init()
                }

                return stateData
            }
        }

        return nil
    }

    private func storeAuthPolicyDomainState() throws {
        if self.vaultType == VaultType.DEVICE_SECURITY.rawValue && self.isEmpty() {
            // this is an empty device security vault

            if !Device().isAvailable {
                throw VaultError.securityNotAvailable
            }

            guard let policyData = self.getCurrentAuthPolicyDomainState() else {
                throw VaultError.unhandledError("could not get auth policy domain state")
            }

            try clearAuthPolicyDomainState()

            let query = [
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: "\(self.config.key)_policyDomainState".data(using: .utf8)!,
                kSecValueData: policyData
            ] as Dictionary

            let status = SecItemAdd(query as CFDictionary, nil)
            guard status != errSecNotAvailable else { throw VaultError.securityNotAvailable }
            guard status == noErr else {
                throw VaultError.unhandledError(status.description)
            }
        }
    }

    private func storeVaultType() throws {
        try clearVaultType()

        let vaultType = self.vaultType ?? ""

        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(self.config.key)_vaultType".data(using: .utf8)!,
            kSecValueData: vaultType.data(using: .utf8)!
        ] as Dictionary

        let status = SecItemAdd(query as CFDictionary, nil)
        guard status != errSecNotAvailable else { throw VaultError.securityNotAvailable }
        guard status == noErr else {
            throw VaultError.unhandledError(status.description)
        }
    }

    private func storeVaultDeviceSecurityType() throws {
        try clearVaultDeviceSecurityType()

        let vaultDST = self.config.deviceSecurityType

        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(self.config.key)_vaultDeviceSecurityType".data(using: .utf8)!,
            kSecValueData: vaultDST.data(using: .utf8)!
        ] as Dictionary

        let status = SecItemAdd(query as CFDictionary, nil)
        guard status != errSecNotAvailable else { throw VaultError.securityNotAvailable }
        guard status == noErr else {
            throw VaultError.unhandledError(status.description)
        }
    }

    private func storeData() throws {
        if !isEmpty() {
            if try self.isVaultInvalidated() {
                try self.clear()
                throw VaultError.invalidatedCredentials
            }
        }
        try storeVaultType()
        try storeVaultDeviceSecurityType()
        try storeAuthPolicyDomainState()
        try clearData()

        let jsonData = try JSONSerialization.data(withJSONObject: self.data ?? "")
        let jsonString = String(data: jsonData, encoding: .utf8) ?? ""

        var query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: self.config.key.data(using: .utf8)!,
            kSecValueData: (jsonString).data(using: .utf8)!
        ] as Dictionary

        if self.accessControl != nil {
            query[kSecAttrAccessControl] = self.accessControl as Any
        }

        if self.authContext != nil {
            query[kSecUseAuthenticationContext] = self.authContext
        }

        let status = SecItemAdd(query as CFDictionary, nil)
        guard status != errSecNotAvailable else { throw VaultError.securityNotAvailable }
        guard status != errSecAuthFailed else {
            self.data = nil
            self.customPasscode = nil
            throw VaultError.authFailed
        }
        guard status == noErr else {
            throw VaultError.unhandledError(status.description)
        }
        refreshIsEmptyFlag()
    }

    private func clearVaultType() throws {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(self.config.key)_vaultType".data(using: .utf8)!
        ] as Dictionary

        let status = SecItemDelete(query as CFDictionary)

        guard status == noErr || status == errSecItemNotFound else { throw VaultError.unhandledError(status.description) }
    }

    private func clearAuthPolicyDomainState() throws {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(self.config.key)_policyDomainState".data(using: .utf8)!
        ] as Dictionary

        let status = SecItemDelete(query as CFDictionary)

        guard status == noErr || status == errSecItemNotFound else { throw VaultError.unhandledError(status.description) }
    }

    private func clearVaultDeviceSecurityType() throws {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: "\(self.config.key)_vaultDeviceSecurityType".data(using: .utf8)!
        ] as Dictionary

        let status = SecItemDelete(query as CFDictionary)

        guard status == noErr || status == errSecItemNotFound else { throw VaultError.unhandledError(status.description) }
    }

    private func clearData() throws {
        var query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: config.self.key.data(using: .utf8)!
        ] as Dictionary

        if self.accessControl != nil {
            query[kSecAttrAccessControl] = self.accessControl as Any
        }

        if self.authContext != nil {
            query[kSecUseAuthenticationContext] = self.authContext
        }

        let status = SecItemDelete(query as CFDictionary)

        guard status == noErr || status == errSecItemNotFound else { throw VaultError.unhandledError(status.description) }
    }

    private func getApplicationSupportDirectory() -> URL? {
        guard let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }

        if !FileManager.default.fileExists(atPath: directory.path) {
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: nil)
            } catch {
                print(error)
            }
        }

        return directory
    }

    private func getFailedUnlockAttempts() throws -> Int {
        let attempts = UserDefaults.standard.integer(forKey: "\(config.key)_unlockAttempts")
        return attempts
    }

    private func setFailedUnlockAttempts(attempts: Int) throws {
        UserDefaults.standard.set(attempts, forKey: "\(config.key)_unlockAttempts")
    }

    private func getIsEmptyFlag() -> Bool {
        if UserDefaults.standard.object(forKey: "\(config.key)_isEmpty") == nil {
            let query = [
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: self.config.key.data(using: .utf8)!,
                kSecUseAuthenticationUI as AnyHashable: kSecUseAuthenticationUIFail
            ] as Dictionary

            let status = SecItemCopyMatching(query as CFDictionary, nil)

            switch status {
            case noErr:
                setIsEmptyFlag(empty: false)
                return false
            case errSecInteractionNotAllowed:
                // If errSecInteractionNotAllowed, the key is present, but we aren't allowed to access it without auth
                setIsEmptyFlag(empty: false)
                return false
            default:
                setIsEmptyFlag(empty: true)
                return true
            }
        } else {
            let isEmpty = UserDefaults.standard.bool(forKey: "\(config.key)_isEmpty")
            return isEmpty
        }
    }

    private func refreshIsEmptyFlag() {
        if !isLocked() {
            setIsEmptyFlag(empty: Array(self.data!.keys).count <= 0)
        }
    }

    private func setIsEmptyFlag(empty: Bool) {
        UserDefaults.standard.set(empty, forKey: "\(config.key)_isEmpty")
    }

    private func clearIsEmptyFlag() {
        UserDefaults.standard.removeObject(forKey: "\(config.key)_isEmpty")
    }

    internal func handleError(error: Error) {
        if let errorCallback = self.onErrorCallback, let callbackId = self.errorCallbackId {
            errorCallback(error, callbackId)
        }
    }
}
