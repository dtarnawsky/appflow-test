import Cordova
import Foundation
import LocalAuthentication

class DeviceSecurityVault: VaultBase {

    override var vaultType: String? {
        return VaultType.DEVICE_SECURITY.rawValue
    }

    override init(_ config: IdentityVaultConfig) throws {
        try super.init(config)

        var accessFlags: [SecAccessControlCreateFlags] = []
        let biometryFlag: SecAccessControlCreateFlags
        if #available(iOS 11.3, *) {
            biometryFlag = SecAccessControlCreateFlags.biometryCurrentSet
        } else {
            biometryFlag = SecAccessControlCreateFlags.touchIDCurrentSet
        }
        switch config.deviceSecurityType {
        case "SystemPasscode":
            accessFlags.append(SecAccessControlCreateFlags.devicePasscode)
        case "Biometrics":
            accessFlags.append(biometryFlag)
        case "Both":
            accessFlags.append(SecAccessControlCreateFlags.devicePasscode)
            if Device().isBiometricsEnabled {
                accessFlags.append(SecAccessControlCreateFlags.or)
                accessFlags.append(biometryFlag)
            }
        default:
            throw VaultError.invalidArguments("deviceSecurityType \(config.deviceSecurityType) is not a valid type for a DeviceSecurityVault")
        }

        self.accessControl = SecAccessControlCreateWithFlags(nil,
                                                             kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                                             SecAccessControlCreateFlags(accessFlags),
                                                             nil)
    }

    override func lock(_ wasTimeout: Bool) throws {
        self.authContext = nil
        try super.lock(wasTimeout)
    }

    override func unlock(_ forceUnlock: Bool = true) throws {
        self.authContext = LAContext()
        if self.config.iosBiometricsLocalizedCancelTitle != nil {
            self.authContext?.localizedCancelTitle = self.config.iosBiometricsLocalizedCancelTitle
        }
        if self.config.iosBiometricsLocalizedFallbackTitle != nil {
            self.authContext?.localizedFallbackTitle = self.config.iosBiometricsLocalizedFallbackTitle
        }
        if self.config.iosBiometricsLocalizedReason != nil {
            self.authContext?.localizedReason = self.config.iosBiometricsLocalizedReason!
        }
        try super.unlock(forceUnlock)
    }

}
