import Cordova
import Foundation

// swiftlint:disable function_body_length identifier_name
// swiftlint:disable type_body_length force_unwrapping
// swiftlint:disable cyclomatic_complexity superfluous_disable_command

public enum VaultError: Error {
    case vaultLocked
    case invalidArguments(_ description: String)
    case invalidatedCredentials
    case vaultUnavailable
    case securityNotAvailable
    case authFailed
    case userCanceledAuth
    case tooManyFailedAttempts
    case keyNotFound
    case mismatchedPasscode
    case biometricsNotEnabled
    case missingPasscode(_ isPasscodeSetRequest: Bool)
    case passcodeNotEnabled
    case invalidAuthMode
    case biometricsLockedOut
    case missingBiometrics // not used on ios
    case systemPasscodeNotAvailable // not used on ios
    case unhandledError(_ description: String)
}

public struct VaultErrorObject {
    let extra: [String: Any]?
    let code: Int
    let message: String
    init(_ code: Int, _ message: String, _ extra: [String: Any]? = nil) {
        self.code = code
        self.message = message
        self.extra = extra
    }

    var asDictionary: [String: Any] {
        return ["code": code, "message": message, "extra": extra ?? []]
    }
}

public func getVaultErrorObject(_ error: Error) -> VaultErrorObject {
    switch error {
    case VaultError.vaultLocked:
        return VaultErrorObject(1, "Operation not allowed while vault locked.")
    case VaultError.vaultUnavailable:
        return VaultErrorObject(2, "Vault Unavailable: Make sure you've configured the vault.")
    case VaultError.invalidArguments(let message):
        return VaultErrorObject(3, "Invalid Arguments Provided: " + message)
    case VaultError.invalidatedCredentials:
        return VaultErrorObject(4, "Credentials invalidated or expired. Vault cleared.")
    case VaultError.securityNotAvailable:
        return VaultErrorObject(5, "Biometric Security unavailable.")
    case VaultError.authFailed:
        return VaultErrorObject(6, "Failed authorization attempt")
    case VaultError.tooManyFailedAttempts:
        return VaultErrorObject(7, "Too many failed attempts. Vault cleared.")
    case VaultError.userCanceledAuth:
        return VaultErrorObject(8, "User canceled auth attempt.")
    case VaultError.mismatchedPasscode:
        return VaultErrorObject(9, "Passcodes did not match.")
    case VaultError.missingPasscode(let isPasscodeSetRequest):
        var extras: [String: Any] = [:]
        extras["isPasscodeSetRequest"] = isPasscodeSetRequest
        return VaultErrorObject(10, "Passcode not setup yet. You must call setPasscode prior to storing values if passcode is enabled", extras)
    case VaultError.passcodeNotEnabled:
        return VaultErrorObject(11, "Passcode not enabled.")
    case VaultError.keyNotFound:
        return VaultErrorObject(12, "Key Not Found")
    case VaultError.biometricsNotEnabled:
        return VaultErrorObject(13, "Biometrics Not Enabled")
    case VaultError.invalidAuthMode:
        return VaultErrorObject(14, "Invalid Auth Mode")
    case VaultError.missingBiometrics:
        return VaultErrorObject(15, "Missing Biometrics")
    case VaultError.systemPasscodeNotAvailable:
        return VaultErrorObject(16, "Option SystemPasscode for deviceSecurityType not available on this device")
    case VaultError.biometricsLockedOut:
        return VaultErrorObject(18, "Biometrics have been locked out.")
    case VaultError.unhandledError(let message):
        return VaultErrorObject(0, "Unhandled Error: " + message)
    default:
        return VaultErrorObject(0, "Unhandled Error: " + error.localizedDescription)
    }
}
