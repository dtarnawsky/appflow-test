//
//  Crypto-Bridging-Header.h
//  auth-play2
//
//  Created by Mano on 14/11/18.
//

#ifndef Crypto_Bridging_Header_h
#define Crypto_Bridging_Header_h

#import <Cordova/CDVPlugin.h>

#import "CommonCrypto/CommonCrypto.h"

#endif /* Crypto_Bridging_Header_h */
