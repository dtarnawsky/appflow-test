//
//  VaultPlugin.h
//  VaultPlugin
//

#import <UIKit/UIKit.h>

//! Project version number for VaultPlugin.
FOUNDATION_EXPORT double VaultPluginVersionNumber;

//! Project version string for VaultPlugin.
FOUNDATION_EXPORT const unsigned char VaultPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VaultPlugin/PublicHeader.h>


