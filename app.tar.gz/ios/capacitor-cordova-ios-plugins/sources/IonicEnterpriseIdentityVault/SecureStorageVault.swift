import Cordova
import Foundation

class SecureStorageVault: VaultBase {
    override var vaultType: String? {
        return VaultType.SECURE_STORAGE.rawValue
    }

    override func lock(_ wasTimeout: Bool) throws {
        return
    }

    override func unlock(_ forceUnlock: Bool = true) throws {
        if self.isLocked() {
            if try self.doesVaultExist() || forceUnlock {
                try self.getData()
            }
        }
    }
}
