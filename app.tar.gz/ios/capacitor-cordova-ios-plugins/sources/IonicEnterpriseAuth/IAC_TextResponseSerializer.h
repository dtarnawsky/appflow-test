#import <Foundation/Foundation.h>
#import "IAC_AFURLResponseSerialization.h"

@interface IAC_TextResponseSerializer : IAC_AFHTTPResponseSerializer

+ (instancetype)serializer;

@end
