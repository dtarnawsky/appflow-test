#import <Foundation/Foundation.h>
#import "IAC_AFURLRequestSerialization.h"

@interface IAC_TextRequestSerializer : IAC_AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
